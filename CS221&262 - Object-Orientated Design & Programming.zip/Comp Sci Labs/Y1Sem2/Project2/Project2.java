
/**
 * GPA Project2
 *
 * @author Nick Lemerond
 * @version 4/3
 * 
 * Ask user for number of classes, grades and credits per class. Will then compute total grade points, total credits and gpa.
 */
import java.util.Scanner;
import java.util.Random;
public class Project2
{
    public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
        Random rand = new Random();
        System.out.print("How many courses this term? (-1 if done): ");
        int courses = scnr.nextInt();
        //Ask user for number of courses (outside while loop)
        int term = 1;
        //Initialize term so each term can count up one
        double cumaGradepoints = 0.0;
        double cumaCredits = 0.0;
        double cumaGpa = 0.0;
        while (courses < 0 && courses > 6) {
            System.out.print("Invalid number of courses. Enter again. (-1 if done); ");
            courses = scnr.nextInt();
        }
        //If too many or too little courses entered, will repeat
        while (courses != -1) { //if user enters -1, while loop will not execute
            System.out.print("Enter the grade and number of credits for each course");
            System.out.println();
            String grade;
            int credits = 0;
            int totCredits = 0;
            double gradeValue = 0.0;
            double totScore = 0.0;
            //creating variables that will change back to zero each new term
            for (int i = 0; i < courses; i++) {
                grade = scnr.next();
                credits = scnr.nextInt();
                //taking in each grade and number of credits for each class
                if (grade.equals("A")) { //assigning grade values to letter grades
                    gradeValue= 4.00;
                } else if (grade.equals("A-")) {
                    gradeValue= 3.67;
                } else if (grade.equals("B+")) {
                    gradeValue = 3.33;
                } else if (grade.equals("B")) {
                    gradeValue = 3.00;
                } else if (grade.equals("B-")) {
                    gradeValue = 2.67;
                } else if (grade.equals("C+")) {
                    gradeValue = 2.33;
                } else if (grade.equals("C")) {
                    gradeValue = 2.00;
                } else if (grade.equals("C-")) {
                    gradeValue = 1.67;
                } else if (grade.equals("D+")) {
                    gradeValue = 1.33;
                } else if (grade.equals("D")) {
                    gradeValue = 1.00;
                } else if (grade.equals("D-")) {
                    gradeValue = 0.67;
                } else if (grade.equals("F")) {
                    gradeValue = 0;
                } else {
                    System.out.println ("Invalid Grade");
                }
                double score = gradeValue * credits;
                //score needed for computing grade points and total score
                totCredits = totCredits + credits;
                //need total credits for calculating gpa
                totScore = totScore + score;
                //need total score for calculating gpa (totalScore is total grade points)
            }
            double gpa = totScore / totCredits;
            //calculating gpa
            gpa = 100 * gpa;
            gpa = (int)gpa;
            gpa = gpa / 100;
            //making gpa up to 2 decimal places
            System.out.println("Summary for term " + term);
            System.out.println("--------------------------------------");
            System.out.println(" Term total grade points:   " + totScore);
            System.out.println("      Term total credits:   " + totCredits);
            System.out.println("                Term GPA:   " + gpa);  
            System.out.println();
            //printout summary
            if (courses != -1) {
                term = term + 1;
            } //////////have no idea why this is still running even if courses are -1
            //adding to term so will print term + 1 next time
            System.out.print("How many courses this term? (-1 if done): ");
            courses = scnr.nextInt();
            while (courses < 0 && courses > 6) {
                System.out.print("Invalid number of courses. Enter again. (-1 if done); ");
                courses = scnr.nextInt();
            }
            //If too many or too little courses entered, will repeat
            cumaGradepoints = cumaGradepoints + totScore;
            cumaCredits = cumaCredits + totCredits;
            //calculating cumulative results
        }
        cumaGpa = cumaGradepoints / cumaCredits; 
        //calculating cumalitive gpa
        cumaGpa = 100 * cumaGpa;
        cumaGpa = (int)cumaGpa;
        cumaGpa = cumaGpa / 100;
        //making gpa up to 2 decimal places
        System.out.println("Final Summary");
        System.out.println("--------------------------------------");
        System.out.println("           Overall terms:   " + term);
        System.out.println("      Total grade points:   " + cumaGradepoints);
        System.out.println("           Total credits:   " + (int)cumaCredits);
        System.out.println("          Cumulative GPA:   " + cumaGpa);  
        System.out.println();
        //Final results
        System.out.println("Done. Normal termination");
    }
}
