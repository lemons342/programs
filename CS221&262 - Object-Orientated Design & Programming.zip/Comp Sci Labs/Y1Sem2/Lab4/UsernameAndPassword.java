
/**
 * BankFees Lab4
 *
 * @author Nick Lemerond
 * @version 3/1
 * 
 * Asks the user for the number of checks written for the month then should then calculates and prints the bank's service fees for the month
 */
import java.util.Scanner;
public class UsernameAndPassword {
    public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
        System.out.print("Enter your full name. ");
        String firstName = scnr.next();
        String lastName = scnr.nextLine();
        //NEED TO read up to 5 characters for lastname
        int random = (int)Math.random() * 100;
        String userName = (lastName + firstName.substring(0,1) + random);
        //username
        System.out.println();
        System.out.print("Enter a password: ");
        String password = scnr.nextLine();
        //password
        System.out.println();
        if ((password.equals(firstName) == true) || (password.equals(lastName) == true)) {
            System.out.println("Error: Password cannot contain your name");       
        } else if (password.length() < 8) {
            System.out.println("Password must be at least 8 characters long");
        } else {
            System.out.print("Comfirm password: ");
            String confPass = scnr.nextLine();
            if (!(password.equals(confPass))){
                System.out.println("Error: Password does not match.");
            } else {                
                System.out.println();
                System.out.println("Account creation successful.");
                System.out.println("Username: " + userName);
            }
        }
    }
}