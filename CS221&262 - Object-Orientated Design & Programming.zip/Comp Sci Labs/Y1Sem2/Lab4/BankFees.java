
/**
 * BankFees Lab4
 *
 * @author Nick Lemerond
 * @version 3/1
 * 
 * Asks the user for the number of checks written for the month then should then calculates and prints the bank's service fees for the month
 */
import java.util.Scanner;
public class BankFees
{
    public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
        System.out.println("How many check written this month?");
        double numChecks = scnr.nextDouble();
        if (numChecks < 20) {
          double checkFee = numChecks * 0.1;
          System.out.print("Bank's service fees: $" + (10 + checkFee));
        } else if ((numChecks >= 20) && (numChecks < 40)){
          double checkFee = numChecks * 0.08;
          System.out.print("Bank's service fees: $" + (10 + checkFee));
        } else if ((numChecks >= 40) && (numChecks < 60)){
          double checkFee = numChecks * 0.06;
          System.out.print("Bank's service fees: $" + (10 + checkFee));
        } else if (numChecks >= 60){
          double checkFee = numChecks * 0.04;
          System.out.print("Bank's service fees: $" + (10 + checkFee));
        } else {
          System.out.print("Error");   
        }
    }
}
