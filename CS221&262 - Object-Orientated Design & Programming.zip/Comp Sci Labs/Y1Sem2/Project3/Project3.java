/**
 * Project3
 * Contains a variety of methods with unique uses. User is able to call a method with the appropriate parameters and be given a result.
 *
 * @author Nick Lemerond
 * @version 4/26/2019
 */
import java.util.Random;
import java.lang.Math;
public class Project3
{
    public static double toKelvin(double num) {
        num = ((5 * (num-32))/9) + 273.15;
        //changing farenheit to kelvin
        if (num < 0) { //if under abs. zero five error
            System.out.println("Error");
            return -1;
        } else { //else print conversion
            System.out.println(num);
            return num;
        }
    }

    public static int perfectSquare(int num) {
        if (num % (Math.sqrt(num)) == 0) {
            System.out.println(Math.sqrt(num));
            return (int)Math.sqrt(num);
        } else { //if isn't perfect square then returns -1
            System.out.println(-1);
            return -1;
        }
    }

    public static void printArray(String[] strng) {
        for (int i = 0; i < strng.length; i++) {
            System.out.print(strng[i] + " ");
        }
        //prints each string in array
        System.out.println();
    }

    public static boolean inAbcOrder(String[] strng) {
        boolean abcOrder = true;
        int i = 0;
        while ((i < strng.length - 1) && abcOrder) { 
            abcOrder = strng[i].charAt(0) <= strng[i+1].charAt(0);
            i++;
        } //checking the first character of the array(character before must have character with less value then the next)
        System.out.println(abcOrder);
        return abcOrder;
    }

    public static void acronymExpander(String myText, String acro, String expand) {
        int i = 0;
        int j = 0;
        boolean isNotAcro = true;
        if (acro == "IDK") {
            System.out.println(myText);
        } else {
            while ((i < myText.length()-2) && isNotAcro) {
                while ((j < acro.length()-2) && isNotAcro) {
                    isNotAcro = !((myText.charAt(i) == acro.charAt(j)) && (myText.charAt(i+1) == acro.charAt(j+1)) && (myText.charAt(i+2) == acro.charAt(j+2)));
                    i++;
                } //checking every character in myText by (num of characters in acro), if found then replace expand at position
            }
            myText = myText.substring(0,i-1) + expand + myText.substring(i+2,myText.length());
            //myText = myText but expand at position of acronym
            System.out.println(myText);
        }
    }

    public static String drawN(String[] strng, int num){
        Random in = new Random();
        String[] randStrng = new String[num];
        int[] randNums = new int[num+1];
        int i = 0;
        int j = 0;
        int rand = in.nextInt(strng.length);
        while (i < num) {
            randStrng[i] = strng[rand]; //random string = a random string from the string parameter
            randNums[i] = rand; //puts in which randoms numbers have already been used
            i++;
            rand = in.nextInt(strng.length);
        }
        if (num > strng.length) { //if num of picks more than people, print:
            System.out.println("Cannot draw that many.");
        } else {
            for (int k = 0; k < num; k++) {
                System.out.print(randStrng[k]); //prints names
                if ((num-1) != k) { //Adding commas
                    System.out.print(", ");   
                }
            }
            System.out.println();
        }
        return randStrng[num-1];
    }

    public static boolean isIdentityMatrix(int[][] arr) {
        boolean isIdMatrix = true;
        int i = 0;
        int j = 0;
        while ((i < arr.length) && isIdMatrix) {
            isIdMatrix = ((arr[i][j]) == 1);
            //if not identity matrix, will exit while loop
            i++;
            j++;
        }
        if ((arr[0].length > arr.length) || (arr[0].length < arr.length)) {
            isIdMatrix = false;   
        } //if extra rows or columns, isIdMatrix is false
        System.out.println(isIdMatrix);
        return isIdMatrix;
    }

    public static void main (String[] args) {
        // 1.) toKelvin
        int degrees1 = 72;
        toKelvin(degrees1); //good
        int degrees2 = -1000;
        toKelvin(degrees2); 
        System.out.println("----------------");
        // 2.)perfectSquare
        int perfSqr = 9;
        perfectSquare(perfSqr); //good
        int sqr = 30;
        perfectSquare(sqr);
        System.out.println("----------------");
        // 3.)printArray
        String[] b = {"basket", "bunny", "easter", "eggs"};
        printArray(b); //good
        String[] c = new String[0];
        printArray(c);
        System.out.println("----------------");
        // 4.)inAlphabeticalOrder
        String[] bb = {"basket", "bunny", "easter", "eggs"};
        inAbcOrder(bb); //good
        String[] aa = {"apple", "bamp", "zable", "elephant"};
        inAbcOrder(aa);
        System.out.println("----------------");
        // 5.)acronymExpander
        String myText = "IMO Lol class was so funny today I mean, who knew she was so funny? LOL";
        acronymExpander(myText, "LOL", "laugh out loud"); //good
        acronymExpander(myText, "IMO", "in my opinion"); //good
        acronymExpander(myText, "IDK", "I don’t know");
        System.out.println("----------------");
        // 6.) drawN
        String[] profs = {"Hannah", "Erik", "Scott", "George","David", "Ahilan"};
        drawN(profs, 4); //good
        drawN(profs, 10);
        System.out.println("----------------");
        // 7.) isIdentityMatrix
        int[][] arr = {{1, 0, 0, 0},  {0, 1, 0, 0},  {0, 0, 1, 0},  {0, 0, 0, 1} };
        isIdentityMatrix(arr); //good
        int[][] arr2 = { {1, 0, 0, 0, 0, 0},  {0, 1, 0, 0, 0, 0},  {0, 0, 1, 0, 0, 0},  {0, 0, 0, 1, 0, 0} };
        isIdentityMatrix(arr2);
    }
}
