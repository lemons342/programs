
/**
 * Lab2
 *
 * @author Nick Lemerond
 * @version 2/15
 * 
 * Runs 2 integers and a double through seven different calculations
 */
import java.util.Scanner;
public class MyNumbers
{
    public static void main (String[] args) {
        //Taking inputs
        Scanner in = new Scanner(System.in);
        System.out.println("Enter first integer.");
        int firstInteger = in.nextInt();
        System.out.println("Enter second integer.");
        int secondInteger = in.nextInt();
        System.out.println("Enter Double."); 
        double firstDouble = in.nextDouble();
        
        //Making calculations
        System.out.println("a. " + (firstInteger - secondInteger - firstDouble));
        System.out.println("b. " + (firstDouble - secondInteger - firstInteger));
        System.out.println("c. " + (firstInteger / secondInteger / firstDouble));
        System.out.println("d. " + (firstDouble / secondInteger / firstInteger));
        System.out.println("e. " + (secondInteger / firstDouble / firstInteger));
        System.out.println("f. " + (firstInteger % secondInteger + firstDouble));
        System.out.println("g. " + (secondInteger % firstInteger + firstDouble));
        }
}
