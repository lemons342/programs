
/**
 * Coins Lab2
 *
 * @author Nick Lemerond
 * @version 2/15
 * 
 * Calculates each coin exchanged for change
 * 
 * Takes coins and multiplies by the value of the coin
 */
import java.util.Scanner;
public class Coins

{
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        // 
        System.out.println("Enter number of quarters.");
        int quarters = in.nextInt();
        System.out.println("Enter number of dimes.");
        int dimes = in.nextInt();
        System.out.println("Enter number of nickels.");
        int nickels = in.nextInt();
        System.out.println("Enter number of pennies.");
        int pennies = in.nextInt();
        //calculations
        System.out.println("Total amount of change: " + ((quarters * 25) + (dimes * 10) + (nickels * 5) + pennies));
        System.out.println("Total amount of coins: " + (quarters + dimes + nickels + pennies));
    }
}
