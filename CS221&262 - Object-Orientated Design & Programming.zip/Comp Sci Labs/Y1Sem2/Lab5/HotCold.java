
/**
 * How/Cold guessing game Lab5
 *
 * @author Nick Lemerond
 * @version 3/15
 * 
 * Asks the user for a guess to adn then outputs hot or cold depending on how close they are
 */
import java.util.Scanner;
import java.util.Random;
public class HotCold
{
    public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
        Random rand = new Random();
        int random = rand.nextInt(100);
        System.out.println(random);
        System.out.println("Enter a guess: ");
        int guess = scnr.nextInt();
        while (guess > 100 || guess < 1) {
            System.out.println("You're freezing!");
            System.out.println("Enter a guess: ");
            guess = scnr.nextInt();
        }
        while ((guess <= 100 && guess >= 1) && !(guess >= (random - 10) && guess <= (random + 10)) && guess != random) {
                System.out.println("You're cold!");
                System.out.println("Enter a guess: ");
                guess = scnr.nextInt();
            }
        while ((guess >= (random - 10) && guess <= (random + 10)) && !(guess >= (random - 5) && guess <= (random + 5)) && guess != random) {
                     System.out.println("You're warm!");
                     System.out.println("Enter a guess: ");
                     guess = scnr.nextInt();
                }
        while (guess >= (random - 5) && guess <= (random + 5) && guess != random) {
                        System.out.println("You're hot!");
                        System.out.println("Enter a guess: ");
                        guess = scnr.nextInt();
                   }
        System.out.println("You got it!");
    }
}
