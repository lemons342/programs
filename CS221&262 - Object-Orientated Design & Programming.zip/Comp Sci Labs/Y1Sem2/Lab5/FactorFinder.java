
/**
 * Factor Finder Lab5
 *
 * @author Nick Lemerond
 * @version 3/15
 * 
 * Asks the user for a number
 * Program then outputs the factors of the number
 * If it is prime, state that it is
 */
import java.util.Scanner;
import java.util.Random;
public class FactorFinder
{
        public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
    
        System.out.println("Find factors for: ");
        int number = scnr.nextInt();
    
        System.out.print("Factors of " + number + " are: ");
        int prime = 0;
        for(int i = 1; i <= number; ++i)
        {
            if (number%i == 0) //Finding factors
            {
                System.out.print(i);
                if (number != i) { //Adding commas
                 System.out.print(", ");   
                }
                prime ++;
            }
        }
        System.out.println();
        if (prime == 2) { // Finding if it is prime
            System.out.print(number + " is a prime number");
        }
    }
}
