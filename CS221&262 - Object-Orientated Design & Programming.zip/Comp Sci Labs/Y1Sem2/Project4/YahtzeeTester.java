import java.util.Scanner;
public class YahtzeeTester
{
    public static void main(String args[]){
        Scanner scanner = new Scanner(System.in);

        // start a new game
        Yahtzee game = new Yahtzee();
        while(!game.isOver()){ 
            // for each turn,
            // user is given a start roll
            game.startRoll();

            // then the user has 3 possible re-rolls, then has to choose a score
            int curRound = 0;
            boolean endTurn = false; // end the turn if the user chooses to score before 3 rolls
            while(!endTurn && curRound <= 3) {
                // for each round

                // display the dice
                game.displayDice();

                // display options for user
                // if the user has already rolled 3 times,
                // the user must choose a score to use
                // the display must also only display valid current options
                game.displayOptions();

                // prompt user for a correct option
                int choice = game.promptUser(scanner);
                switch(choice) {
                    case 1:
                        // choice was to roll dice, 
                        // pick which one to roll
                        int die = game.pickDieToRoll(scanner);
                        // roll the die picked
                        game.roll(die);
                        break;

                    case 2:
                        // choice was to score a yahtzee
                        // if the game is a yahtzee, add 50 points to total score, 0 otherwise
                        if(game.isYahtzee()){
                            game.addTotal(50);
                        } else{
                            game.addTotal(0);
                        }
                        
                        // do not allow yahtzee to be chosen again
                        // (tell the game, no more yahtzee)
                        game.noMoreYahtzee();
                        endTurn = true;  //end the turn
                        break;
                        
                    case 3:
                        // choice was to score a straight
                        // if the game is a straight, add 25 points to total score, 0 otherwise
                        if(game.isStraight()){
                            game.addTotal(25);
                        } else{
                            game.addTotal(0);
                        }
                        
                        // do not allow straight to be chosen again
                        // (tell the game, no more straight)
                        game.noMoreStraight();
                        endTurn = true;  //end the turn
                        break;
                        
                    case 4:
                        // choice was to score chance
                        // add the dice values and add that sum to the score
                        int diceTotal = game.addDice();
                        game.addTotal(diceTotal);
                        
                        // do not allow chance to be chosen again
                        game.noMoreChance();
                        endTurn = true;  //end the turn
                } // end switch
                
                curRound++;
            }
            
            // display information at the end of each turn (current score)
            game.displayInformation();
        }
        
        // display information at the end of the game (final score)
        game.displayFinals();
    }
}
