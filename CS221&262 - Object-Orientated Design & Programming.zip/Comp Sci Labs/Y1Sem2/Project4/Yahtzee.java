/**
 * Write a description of class Yahtzee here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Random;
import java.util.Scanner;
public class Yahtzee
{
    private int[] dice = new int[3];
    private int total = 0;
    private int curRound = 0;
    private boolean isOver = false;
    private boolean noMoreYahtzee = false;
    private boolean noMoreStraight = false;
    private boolean noMoreChance = false;
    public boolean isOver() {
        return isOver; //returns private boolean variable
    }

    public void startRoll() {
        curRound = 0;
        Random rand = new Random();
        for (int i = 0; i < dice.length; i++) {
            dice[i] = rand.nextInt(6) + 1;
        }
        //"rolls dice" up to dice length (number of dice)
    }

    public void displayDice() {
        System.out.print("Dice are: ");
        for (int i = 0; i < 3; i++) {
            System.out.print(dice[i]+" ");
        }
        System.out.println();
        //prints dice that are rolled
    }

    public void displayOptions() {
        if (curRound != 3) { //prints only three times
            System.out.println("1 to roll a single dice.");
        }
        if (!noMoreYahtzee) { //prints when yahtzee isnt used
            System.out.println("2 for yahtzee score.");
        }
        if (!noMoreStraight) { //prints when straight is used
            System.out.println("3 for straight score.");
        }
        if (!noMoreChance) { //prints when change is used
            System.out.println("4 for chance score.");
        }
    }

    public int promptUser(Scanner scnr) {
        System.out.println("Enter a choice: ");
        int choice = scnr.nextInt();
        while (curRound == 3 && choice == 1) { //user can't use a yahtzee/straight/chance when it has already been used
            System.out.println("ERROR, try again.");
            choice = scnr.nextInt();
        }
        while (noMoreYahtzee && choice == 2) {
            System.out.println("ERROR, try again.");
            choice = scnr.nextInt();
        }
        while (noMoreStraight && choice == 3) {
            System.out.println("ERROR, try again.");
            choice = scnr.nextInt();
        }
        while (noMoreChance && choice == 4) {
            System.out.println("ERROR, try again.");
            choice = scnr.nextInt();
        }
        return choice;
    }

    public int pickDieToRoll(Scanner scnr) {
        System.out.println("Pick die to roll.");
        int die = scnr.nextInt(); //asking which die to re-roll  
        while (die > dice.length) { //checking if its actually a die
            System.out.println("Invalid choice, try again");
            die = scnr.nextInt(); 
        }
        return die;
    }

    public void roll(int val) {
        Random rand = new Random();
        dice[val-1] = rand.nextInt(6)+1; //dice chosen is now re-rolled to be something random
        curRound++; //keeping track of re-rolls used, max of 3
    }

    public void addTotal(int val) {
        total = total + val; //adding score --> private int
    }

    public boolean isYahtzee() {
        boolean isYahtzee = false;
        if (!noMoreYahtzee) {
            int i = 0;
            isYahtzee = (dice[i] == dice[i+1]); //testing if first dice is the same as second
            if (isYahtzee) { // if so then
                i++;
                isYahtzee = (dice[i] == dice[i+1]); //check if second die is same as third
            }
        }
        return isYahtzee;
    }

    public void noMoreYahtzee() {
        noMoreYahtzee = true; //cant use yahtzee anymore
        curRound++; //keeping track
    }

    public boolean isStraight() {
        boolean isStraight = false;
        if (!noMoreStraight) {
            int i = 0;
            //checking 123456
            isStraight = ((dice[i] +1) == dice[i+1]); //checking if first is less than second by 1
            if (isStraight) { //if so then
                i++;
                isStraight = ((dice[i] +1) == dice[i+1]); //checking if second is less than third by 1
            } 
            //checking 654321
            if (!isStraight) { //if still false
                i = 0;
                isStraight = (dice[i] == (dice[i+1] +1)); //checking if first is greater than second by 1
                if (isStraight) { //if so then
                i++;
                isStraight = (dice[i] == (dice[i+1] +1)); //checking if second is greater than third by 1
            } 
            }
        }
        
        return isStraight;
    }

    public void noMoreStraight() {
        noMoreStraight = true; //cant use straight anymore
        curRound++; //leeping track
    }

    public int addDice() {
        int diceTotal = 0;
        for (int i = 0; i < dice.length; i++) {
            diceTotal = diceTotal + dice[i]; //adding dice
        }
        return diceTotal;
    }

    public void noMoreChance() {
        noMoreChance = true; //cant use chance anymore
        curRound++; //keeping track
    }

    public void displayInformation() {
        System.out.println();
        System.out.println("Your current total is: " + total); //prints total
        if (noMoreYahtzee && noMoreStraight && noMoreChance) { //if all options used, game is over
            isOver = true;
        }
        System.out.println();
    }

    public void displayFinals() {
        System.out.println("Your final total is: " + total); //final total
    }
}
