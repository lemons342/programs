
/**
 * Reverse! Reverse! Lab6
 *
 * @author Nick Lemerond
 * @version 4/4
 * 
 * Allow the user to enter a number, and then print out whether the number is prime or not
 */
import java.util.Scanner;
import java.util.Random;
public class Prime
{
    public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
        Random rand = new Random();
        System.out.println("Enter a number");
        int num = scnr.nextInt();
        boolean isPrime = false;
        for(int i = 2; i < num; i++) {
            if (num % i == 0) {
                isPrime = true;
                break;
            }
        }
        if (!isPrime) {
            System.out.println(num + " is a prime number");  
        } else {
            System.out.println(num + " is not a prime number");   
        }
    }   
}