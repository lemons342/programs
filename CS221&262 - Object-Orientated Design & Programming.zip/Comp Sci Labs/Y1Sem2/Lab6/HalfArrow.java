
/**
 * Reverse! Reverse! Lab6
 *
 * @author Nick Lemerond
 * @version 4/4
 * 
 * Allow a user to enter an arrow base height, an arrow base width, and an arrow head width for half of an arrow
 */
import java.util.Scanner;
import java.util.Random;
public class HalfArrow
{
    public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
        Random rand = new Random();
        System.out.println("Enter arrow base height: ");
        int height = scnr.nextInt();
        System.out.println("Enter arrow base width: ");
        int widthB = scnr.nextInt();
        System.out.println("Enter arrow head width: ");
        int widthH = scnr.nextInt();
        int decrease = widthH;
        for (int i = height; i > 0; i--) {
            for (int ii = widthB; ii > 0; ii--) {
                System.out.print("*");
            }
            System.out.println();
        }
        for (int i = widthH; i > 0; i--) {
         for (int ii = decrease; ii > 0; ii--) {
                System.out.print("*");
            }
         System.out.println();
         decrease = decrease -1; 
        }
    }
}
