
/**
 * Reverse! Reverse! Lab6
 *
 * @author Nick Lemerond
 * @version 4/4
 * 
 * Allow  the  user  to  enter  some  text,  then  output  the  text  in  reverse  order  followed  by  the  original order.
 */
import java.util.Scanner;
import java.util.Random;
public class Reverse
{
    public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
        Random rand = new Random();
        System.out.println("Enter some text: ");
        String word = scnr.nextLine();
        for (int i = word.length(); i > 0; i--) {
         System.out.print(word);
         System.out.print(word.charAt(i - 1));   
        }
                
    }
}
