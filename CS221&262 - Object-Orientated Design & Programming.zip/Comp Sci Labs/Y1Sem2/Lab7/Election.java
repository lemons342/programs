
/**
 * Election
 *
 * @author Nick Lemerond
 * @version 4/11
 * 
 * Read in the names of the interested runners. Finally, output the possible running pairs
 */
import java.util.Scanner;
public class Election
{
    public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
        System.out.print("How  many people are interested in running for office? ");
        int peopleRunning = scnr.nextInt();
        System.out.println();
        String namesArray[] = new String[peopleRunning];
        for (int i = 0; i < peopleRunning; i++) {
            System.out.print("Person " + (i + 1) + ": ");
            namesArray[i] = scnr.next();
        }
        System.out.println("The possible running pairs are:");
        for (int i = 0; i < peopleRunning; i++) {
            for (int ii = 1; ii < peopleRunning; ii++) {
                if ((i + ii) < peopleRunning) {
                    System.out.print("P: " + namesArray[i] + ", ");
                    System.out.println("    VP: " + namesArray[i+ii]);
                } else if ((ii-i) < 0){
                    System.out.print("P: " + namesArray[i] + ", ");
                    System.out.println("    VP: " + namesArray[i-ii]);
                } else {
                    System.out.print("P: " + namesArray[i] + ", ");
                    System.out.println("    VP: " + namesArray[ii-i]);
                }
            }
        }
    }
}
