
import java.util.Scanner;

public class ModifyArray {

   public static void swapArrayEnds(int[] arr, int num) {
      int tmpStore = 0;
      tmpStore = arr[0];
      arr[0] = arr[num-1];
      arr[num-1] = tmpStore;
   }

   public static void main (String [] args) {
      int numElem = 4;
      int[] sortArray = new int[numElem];
      int i;

      sortArray[0] = 10;
      sortArray[1] = 20;
      sortArray[2] = 30;
      sortArray[3] = 40;

      swapArrayEnds(sortArray, numElem);

      for (i = 0; i < numElem; ++i) {
         System.out.print(sortArray[i]);
         System.out.print(" ");
      }
      System.out.println("");
   }
}