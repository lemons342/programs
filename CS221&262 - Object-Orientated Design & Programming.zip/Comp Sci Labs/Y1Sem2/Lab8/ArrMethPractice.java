
/**
 * Write a description of class ArrMethPractice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Random;
public class ArrMethPractice

{
    public static int getOdd() {
        Random rand = new Random();
        int getOdd = rand.nextInt(10);
        while (getOdd % 2 != 1) {
            getOdd = rand.nextInt(10);
        }
        return getOdd;
    }

    public static int arr;getEven() {
        Random rand = new Random();
        int getEven = rand.nextInt(10);
        while (getEven % 2 != 0) {
            getEven = rand.nextInt(10);
        }
        return getEven;
    }

    public static void main (String[] args) {
        System.out.println(getOdd() + 10);
        System.out.println(getEven() + 10); 
        int numArray[] = new int[10];
        for (int i = 1; i < 10; i=+2) {
            numArray[i-1] = (getEven() + 10);
            numArray[i] = (getOdd() + 10); 
        }
        for (int i = 0; i < 10; i=+2) {
            System.out.print(numArray[i] + " ");
        }
    }
}
