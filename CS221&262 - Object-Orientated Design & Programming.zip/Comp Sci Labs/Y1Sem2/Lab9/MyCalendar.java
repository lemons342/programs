
/**
 * Write a description of class MyCalendar here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MyCalendar
{
    private int day;
    private int month;
    private int year;
    
    public MyCalendar() {
        day = 1;
        month = 1;
        year = 1;
    }
    
    public MyCalendar(int d, int m, int y) {
        day = d;
        month = m;
        year = y;
    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return day;
    }

    public void setDay(int val) {
        day = val;
    }

    public void setMonth(int val) {
        month = val;
    }

    public void setYear(int val) {
        month = val;
    }

    public void printDate() {
        System.out.println(month + "/" + day + "/" + year);
    }

    public void printDate(int val) {
        if (val == 0) {
            System.out.println(month + "/" + day + "/" + year);
        } else if (val == 1) {
            System.out.println(day + "/" + month + "/" + year);
        } else if (val == 2) {
            System.out.println(year + "/" + month + "/" + day);
        } else if (val == 3) {
            System.out.printf(month + "/" + day + "/%02d\n",(year%100));
        } else if (val == 4) {
            System.out.printf(day + "/" + month + "/%02d\n",(year%100));
        } else {
            System.out.println("ERROR");
        }
    }
}
