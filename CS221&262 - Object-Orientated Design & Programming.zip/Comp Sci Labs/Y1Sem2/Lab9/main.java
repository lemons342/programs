
/**
 * Write a description of class main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class main
{
    public static void main(String[] args) {
        MyCalendar test1 = new MyCalendar(4,5,2000);
        MyCalendar test2 = new MyCalendar(10,11,2010);
        
        test1.printDate();
        test2.printDate(3);
        
        /*
        Square mySquare; // declared (not initialized)
        Rectangle myRectangle;
        
        mySquare = new Square(); // created/intialized
        myRectangle = new Rectangle();
        
        Square square2 = new Square(5); // declared and created/initialized in one step
        Rectangle rectangle2 = new Rectangle(4,7);
        
        //System.out.println("My square has side length " + mySquare.sideLength); 
        System.out.println("My square has side length " + mySquare.getSideLength());
        
        int area1 = mySquare.computeArea();
        System.out.println(area1);
        
        System.out.println("mySquare perimeter: " + mySquare.computePerimeter());
        System.out.println(square2.computeArea());
        System.out.println(square2.computePerimeter());
        
        System.out.println(myRectangle.computeArea());
        System.out.println(myRectangle.computePerimeter());
        System.out.println(rectangle2.computeArea());
        System.out.println(rectangle2.computePerimeter());
        */
    }
}
