
/**
 * Taking a person’s first and last name as one line of input, and a credit card number as a second line of input, and
 * outputs the person’s username and masked credit card number.
 * @author Nick Lemerond
 * @version 2/27
 */
import java.util.Scanner;
public class AccountInfo
{
    public static void main(String args[]) {
        Scanner scnr = new Scanner(System.in);
        System.out.println("Enter your full name.");
        String firstName = scnr.next();
        String lastName = scnr.nextLine();
        System.out.println("Enter your credit card number.");
        String cardNumber = scnr.next();
        
        System.out.println("Your username is: " + lastName + firstName.substring(0,1));
        System.out.println("You entered credit card: ************" + cardNumber.substring(cardNumber.length() - 4,cardNumber.length()));
        //Takes length of string - 4 for minumum parameter and prints out last 4 characters typed in input
    }
}
