
/**
 * Implement fibonnaci formula
 *
 * @author Nick Lemerond
 * @version 2/22
 */
import java.util.Scanner;
public class Fibonacci
{
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        System.out.print("Input: ");
        double inputN = in.nextDouble();
        //Taking input
        final double SQRT_FIVE = Math.sqrt(5.0);
        //Constant variable sqrt of 5
        final double FIRSTPART = ((1.0 + SQRT_FIVE) / 2.0);
        final double SECONDPART = ((1.0 - SQRT_FIVE) / 2.0);
        //Seperating parts of the forumla into double to simplify
        double fibonacci = (1.0 / SQRT_FIVE) * ((Math.pow((FIRSTPART),inputN)) - (Math.pow((SECONDPART),inputN)));
        //Formula
        System.out.println(fibonacci);   
    }
}
