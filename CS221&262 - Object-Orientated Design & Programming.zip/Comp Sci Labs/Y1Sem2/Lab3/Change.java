
/**
 * Coins Lab2
 *
 * @author Nick Lemerond
 * @version 2/15
 * 
 * Calculates each coin exchanged for change
 */
import java.util.Scanner;
public class Change

{
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        // Algorithm: change / 25 = numQuarters
        // change % 25 = remainder --> (change % 25) / 10 = numDimes
        // keep using remainder and dividing by value of coin
        System.out.println("Enter amount of item.");
        System.out.print("$: ");
        double priceItem = in.nextDouble();
        priceItem = priceItem * 100;
        System.out.println("Enter payment.");
        System.out.print("$: ");
        double payment = in.nextDouble();
        payment = payment * 100;
        //calculations
        int change = (int)payment - (int)priceItem;
        System.out.println("Number of dollars: " + (change / 100));
        System.out.println("Number of quarters: " + ((change % 100) / 25));
        System.out.println("Number of dimes: " + (((change % 100) % 25) / 10));
        System.out.println("Number of nickels: " + ((((change % 100) % 25) % 10)) / 5);
        System.out.println("Number of pennies: " + (((((change % 100) % 25) % 10)) % 5) / 1);
        
    }
}
