import java.util.Scanner;
import java.util.Random;
/**
 * Read REAM ME file
 *
 * @author Nick Lemerond
 * @version 10/4 (Using late day)
 */
public class Project1
{
    private static int counter = 1; 
    public static void main(String args[]) {
        System.out.println("!! Welcome to Project 1 !!");
        Scanner in = new Scanner(System.in);
        System.out.print("Enter exponent: ");
        int exp = in.nextInt();

        int[][] board = getRandomBoard(exp); //board created
        printBoard(board); //print board
        tileCheckerboardRec(board, 0, board.length, 0, board.length);
        printBoard(board);

        System.out.println("Done. Normal termination.");
    }

    public static void tileCheckerboardRec(int[][] board, int left, int right, int top, int bottom) {
        if(((isQuadrantEmpty(board, left, right, top, bottom) == false)) && ((right - left) == 1)) {
        } else {
            counter++;
            if ((isQuadrantEmpty(board, left, (left + right)/2, top, (top + bottom)/2)) == true) {
                board[((top + bottom)/2)-1][((left + right)/2)-1] = counter;   
            }//upper left quadrant being filled and filling corner for triomino
            if ((isQuadrantEmpty(board, (left + right)/2, right, top, (top + bottom)/2)) == true) {
                board[((top + bottom)/2)-1][((left + right)/2)] = counter;   
            }//upper right quadrant being filled and filling corner for triomino
            if ((isQuadrantEmpty(board, left, (left + right)/2, (top + bottom)/2, bottom)) == true) {
                board[((top + bottom)/2)][((left + right)/2)-1] = counter;   
            }//bottom left quadrant being filled and filling corner for triomino
            if ((isQuadrantEmpty(board, (left + right)/2, right, (top + bottom)/2, bottom)) == true) {
                board[((top + bottom)/2)][((left + right)/2)] = counter;   
            }//bottom right quadrant being filled and filling corner for triomino
            //filling all the quadrants

            tileCheckerboardRec(board, left, (left + right)/2, top, (top + bottom)/2); //going through all top left quadrants
            tileCheckerboardRec(board, (left + right)/2, right, top, (top + bottom)/2); //going through all top right quadrants
            tileCheckerboardRec(board, left, (left + right)/2, (top + bottom)/2, bottom); //going through all bottom left quadrants
            tileCheckerboardRec(board, (left + right)/2, right, (top + bottom)/2, bottom); //going through all bottom right quadrants
        }
    }

    public static boolean isQuadrantEmpty(int[][] board, int left, int right, int top, int bottom) {
        boolean empty = true;
        int i = 0;
        while (i < (bottom - top)) {
            for (i = 0; i < bottom - top; i++) {
                for (int j = 0; j < right - left; j++) {
                 if (board[top + i][left + j] > 0) {
                     empty = false;
                    }
                }
            }
        }
        return empty;
    }

    public static int[][] getRandomBoard(int exp) {
        Random rand = new Random();
        int row;
        int col; // #rowcol
        int[][] board;
        int num = 1;

        for(int i = 0; i < exp; i++) {
            num = num * 2; //wouldn't let me to math.pow even with import :(
        } //getting length of board

        board = new int[num][num];

        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                board[i][j] = 0;   
            }
        } //filing board with 0

        row = rand.nextInt(num); //getting random row
        col = rand.nextInt(num); //getting random column
        board[row][col] = 1; //assigning 1 to random rowcol

        return board;
    }

    public static void printBoard(int[][] board) {
        int size = digitCount(counter); //size of digits so we know how many times to print '-'

        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length * 2; j++) {
                if (j % 2 == 0) { //when even
                    System.out.print("+");
                } else { //when odd
                    for(int k = 0; k < size; k++) {
                        System.out.print("-");   
                    }
                }
            } 
            System.out.println("+"); //prints last '+' and creates newline

            for (int l = 0; l < board[i].length; l++) { //printing inbetween numbers
                System.out.print("|");
                for (int m = 0; m < size - digitCount(board[i][l]); m++) {
                    System.out.print(" ");
                }
                System.out.print(board[i][l]); //prints num
            }
            System.out.println("|"); //print last '|'
        }

        for (int i = 0; i < board.length * 2; i++) { //print last row of +--+
            if (i % 2 == 0) {
                System.out.print("+");   
            } else {
                for(int j = 0; j < size; j++) {
                    System.out.print("-");   
                }
            }
        }
        System.out.println("+"); //print last '+'
    }

    public static int digitCount(int digit) { //helper method to count digits
        int count = 0; 
        if (digit == 0) {
            count = 1; //so that code doesn't return an error for 0
        } else {
            int quotient = digit;
            while (quotient > 0) {
                quotient = quotient / 10;
                count++;
            }
        }
        return count; //return number of digits so we know how many '-' to use inbetween each '+'
    }
}
