
/**
 * Enlargeable Class enlarges area and perimeter
 */
public interface Enlargeable
{
    /**
     * enlarges area
     */
    public void enlargeArea(double k);

    /**
     * enlarges perimeter
     */
    public void enlargePerimeter(double k);

    /**
     * gets area
     */
    public double getArea();

    /**
     * gets perimeter
     */
    public double getPerimeter();
}
