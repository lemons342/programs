
/**
 * MyCircle Class
 */
public class MyCircle extends Shape 
{
    private double radius;
    private double area;
    private double perimeter;

    /**
     * Default MyCircle method
     */
    public MyCircle() {
        radius = 1;
    }

    /**
     * MyCircle method that takes radius
     */ 
    public MyCircle(double rad) {
        radius = rad;
    }

    /**
     * sets redius
     */     
    public void setRadius(double rad) {
        radius = rad;
    }

    /**
     * gets area
     */     
    public double getArea() {
        return area = 2 * Math.PI * radius * radius;
    }

    /**
     * gets perimeter
     */     
    public double getPerimeter() {
        return perimeter = 2 * Math.PI * radius;
    }

    /**
     * enlarges area
     */    
    public void enlargeArea(double k) {
        area = (2 * Math.PI * radius * radius) * k;
    }

    /**
     * enlarges perimeter
     */    
    public void enlargePerimeter(double k) {
        perimeter = (2 * Math.PI * radius) * k;
    }

    /**
     * Reads out data
     */    
    @Override
    public String toString() {
        String result = "Circle has a redius of " + radius + ", Area = " + area + ", Perimeter = " + perimeter;;
        return result;
    }
}
