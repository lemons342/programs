
/**
 * MyRectangle Class
 */
public class MyRectangle extends Shape
{
    private double length;
    private double width;
    private double area;
    private double perimeter;
    /**
     * Default MyRectangle method
     */
    public MyRectangle() {
        this.length = 1;
        width = 1;
    }

    /**
     * MyRectangle method that takes length
     */   
    public MyRectangle(double length) {
        this.length = length;
        width = 1;
    }

    /**
     * MyRectangle method that takes length and width
     */
    public MyRectangle(double givenLength, double givenWidth) {
        length = givenLength;
        width = givenWidth;
    }

    /**
     * sets length
     */
    public void setLength(double newLength) {
        this.length = newLength;
    }

    /**
     * sets width
     */
    public void setWidth(double newWidth) {
        this.width = newWidth;
    }

    /**
     * gets perimeter
     */
    public double getPerimeter() { 
        return perimeter = 2 * length + 2 * width;
    }

    /**
     * gets area
     */
    @Override
    public double getArea() {
        return area = length * width;
    }

    /**
     * enlarges area
     */
    public void enlargeArea(double k) {
        area = (length * width) * k;
    }

    /**
     * enlarges perimeter
     */
    public void enlargePerimeter(double k) {
        perimeter = (2 * length + 2 * width) * k;
    }

    /**
     * Reads out data
     */
    @Override
    public String toString() {
        String result = "Rectangle is " + length + "x" + width + ", Area = " + area + ", Perimeter = " + perimeter;;
        return result;
    }
}
