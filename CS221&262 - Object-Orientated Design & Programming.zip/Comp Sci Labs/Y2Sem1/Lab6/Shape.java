
/**
 * Shape Class
 */
public abstract class Shape implements Enlargeable
{
    public Shape() {
    }
    /**
     * gets area
     */    
    public abstract double getArea();
    /**
     * gets perimeter
     */    
    public abstract double getPerimeter();
}
