
/**
 * Runs set length, width, and radius to shapes, reads toStrings and enlarges
 *
 * @author Nick Lemerond
 * @version 10/25
 */
public class Driver
{
    public static void main(String[] args) {
        /*Shape[] shapes = new Shape[5];
        for(int i = 0; i < 5; i++) {
            if(Math.random() > 0.5) {
                shapes[i] = new MyRectangle();
            } else {
                shapes[i] = new MyCircle();
            }
        }
        
        for(Shape s : shapes) {
            System.out.println(s.getArea());
            System.out.println(s.getPerimeter());
        } 
        
        System.out.println();
        */
        MyRectangle rect = new MyRectangle();
        MyCircle circ = new MyCircle();
        
        rect.setLength(5);
        rect.setWidth(3);
        System.out.println(rect.getArea());
        System.out.println(rect.getPerimeter());
        //System.out.println(rect.enlargeArea(2));
        //System.out.println(rect.enlargePerimeter(2));
        System.out.println(rect.toString());
        
        circ.setRadius(4);
        System.out.println(circ.getArea());
        System.out.println(circ.getPerimeter());
        circ.enlargeArea(3);
        circ.enlargePerimeter(3);
        System.out.println(circ.toString());
    }
}
