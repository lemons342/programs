import java.io.*;
import java.util.*;
/**
 * Write a description of class AlmostPalTest here.
 *
 * @author Nick Lemerond
 * @version 11/15
 */
public class AlmostPalTest
{
    public static void readPal() {
        File inFile = new File("Project3SampleInput/dictionary.txt");
        Scanner in = null;
        PrintWriter out = null;

        try {
            in = new Scanner(inFile);
            int wordCount = 0;
            while (in.hasNext()) {
                wordCount++;
                in.next();
            }
            in.close();
            in = new Scanner(inFile);

            MyWord[] array = new MyWord[wordCount];

            for (int i = 0; i < array.length; i++) {
                array[i] = new MyWord();
                array[i].word = in.next();
            }

            out = new PrintWriter("almostPalOutput.txt");
            
            for (int i = 0; i < wordCount; i++) {
                if (isAlmostPalindromeRec(array[i].word, 0)) {
                out.print(array[i].word + "\n");
            }
            }
        } catch (Exception e) {
            System.out.println("Error. Exception occured.");
        } finally {
            if(in != null) {
                in.close();
            }
            if(out != null) {
                out.close();
            }
        }
    }

    public static boolean isAlmostPalindromeRec(String str, int letter) {
        int oneLetter = letter;
        if(str.length() <= 1) { //palindrome is length gets to 0 or 1
            return true;
        } if (str.charAt(0) != str.charAt(str.length() - 1)) {
            oneLetter++;
        } if ((str.charAt(0) == str.charAt(str.length() - 1)) || (oneLetter < 2)) { //if still is palindrome keep going through recursion
            return isAlmostPalindromeRec((str.substring(1, str.length()-1)),oneLetter);
        }
        return false; //returns false if none of the if statement are met
    }
}
