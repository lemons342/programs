
/**
 * Write a description of class MyWord here.
 *
 * @author Nick Lemerond
 * @version 11/15
 */
public class MyWord implements Comparable
{
    public String word;

    @Override
    public int compareTo(Object n){
        int order = 0;
        String tempStringObject = "";
        String tempStringThis = "";
        if(n instanceof MyWord){
            for(int i = 0; i < ((MyWord)n).word.length(); i++){
                char temp = ((MyWord)n).word.charAt(i);
                if((int) temp >= 65 && (int) temp <= 90){
                    int ascii = (int) temp;
                    ascii += 32;
                    temp = (char) ascii;

                    tempStringObject += temp;
                }
                else{
                    tempStringObject += ((MyWord)n).word.charAt(i);
                }
            }

            for(int i = 0; i < this.word.length(); i++){
                char temp = this.word.charAt(i);
                if((int) temp >= 65 && (int) temp <= 90){
                    int ascii = (int) temp;
                    ascii += 32;
                    temp = (char) ascii;

                    tempStringThis += temp;
                }
                else{
                    tempStringThis += this.word.charAt(i);
                }
            }
            int i = 0;
            while(order == 0 && (i < tempStringThis.length() && i < tempStringObject.length())){

                if((int) tempStringThis.charAt(i) > (int) tempStringObject.charAt(i)){
                    order = -1;
                }
                if(tempStringThis.charAt(i) < tempStringObject.charAt(i)){
                    order = 1;
                }
                if(((i+1) == tempStringThis.length() || (i+1) == tempStringObject.length()) && order == 0 && tempStringThis.length() != tempStringObject.length()){
                    if(tempStringThis.length() > tempStringObject.length()){
                        order = -1;
                    }
                    else{
                        order = 1;
                    }
                }
                i++;
            }
        }
        return order;
    }
}
