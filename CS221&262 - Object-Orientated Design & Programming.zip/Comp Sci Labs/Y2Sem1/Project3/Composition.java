
/**
 * Write a description of class Composition here.
 *
 * @author Nick Lemerond
 * @version 11/15
 */
public class Composition
{
    
}
