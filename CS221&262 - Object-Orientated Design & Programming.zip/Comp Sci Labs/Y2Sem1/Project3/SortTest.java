import java.io.*;
import java.util.*;
/**
 * Write a description of class SortTest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SortTest
{
    public static void readFile() {
        File inFile = new File("Project3SampleInput/input.txt");
        Scanner in = null;
        PrintWriter out = null;

        try {
            in = new Scanner(inFile);
            int wordCount = 0;
            while (in.hasNext()) {
                wordCount++;
                in.next();
            }
            in.close();
            in = new Scanner(inFile);

            MyWord[] array = new MyWord[wordCount];

            for (int i = 0; i < array.length; i++) {
                array[i] = new MyWord();
                array[i].word = in.next();
            }

            Arrays.sort(array);

            out = new PrintWriter("output.txt");

            for (int i = 0; i < wordCount; i++) {
                out.print(array[i].word + " ");
            }
        } catch (Exception e) {
            System.out.println("Error. Exception occured.");
        } finally {
            if(in != null) {
                in.close();
            }
            if(out != null) {
                out.close();
            }
        }
    }

}
