
/**
 * Write a description of class LightsOutPlayer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LightsOutPlayer extends DuoplayPlayer
{
    protected String name;
    protected int state;
    /**
     * assigns name to protected name
     * @param name, type: String, purpose: assigns name to protected name
     */
    public void playerName(String name) {
        this.name = name;
    }
    
    /**
     * Moves
     */
    public int move(int state) {
        
        return state;
    }
}
