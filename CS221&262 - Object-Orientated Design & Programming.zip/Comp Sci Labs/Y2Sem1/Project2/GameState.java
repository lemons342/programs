
/**
 * Write a description of class GameState here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public enum GameState {WON, DRAW, IN_PROGRESS}

