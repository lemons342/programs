
/**
 * Write a description of class Duoplay here.
 *
 * @author Nick Lemerond
 * @version 10/30
 */
public abstract class Duoplay
{
    DuoplayPlayer player1;
    DuoplayPlayer player2;
    /**
     * Contructor takes player1, player2
     * @param p1, type: DuoplayPlayer, purpose: create player 1
     * @param p2, type: DuoplayPlayer, purpose: create player 2
     */
    public void Duoplay(DuoplayPlayer p1, DuoplayPlayer p2) {
        player1 = p1;
        player2 = p2;
    }
    /**
     * Play method to figure out state of game
     */
    public void play() {
        GameState state = GameState.IN_PROGRESS;
        while(state == GameState.IN_PROGRESS) {
            System.out.print(this.toString());
            System.out.println(player1.getName() + "'s turn!");
            state = player1.move(this);
            if (state == GameState.WON && state !=GameState.DRAW) {
                System.out.println(this.toString());
                state = player2.move(this);
                if (state == GameState.WON) {
                    System.out.println(player1.getName() + " won the game!");
                } else if (state == GameState.DRAW) {
                    System.out.println("The game is a draw");
                }
            }   else if (state == GameState.WON) {

            } else if (state == GameState.DRAW) {
                System.out.println("The game is a draw");
            }
        }

    }
}
