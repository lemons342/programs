
/**
 * Write a description of class DuoplayPlayer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class DuoplayPlayer extends Duoplay
{
    protected String name;
    protected int state;
    /**
     * assigns name to protected name
     * @param name, type: String, purpose: assigns name to protected name
     */
    public void playerName(String name) {
        this.name = name;
    }
    /**
     * Gets name
     */
    public String getName() {
        return name;
    }
    /**
     * Moves
     */
    public abstract int move(int state);
}
