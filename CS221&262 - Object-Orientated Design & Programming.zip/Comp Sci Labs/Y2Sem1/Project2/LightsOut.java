import java.util.*;
/**
 * Write a description of class Lightsout here.
 *
 * @author Nick Lemerond
 * @version 10/30
 */
public class LightsOut extends Duoplay
{
    int[][] board;
    /**
     * Contructor takes player1, player2, and n
     * @param p1, type: LightsOutPlayer, purpose: create player 1
     * @param p2, type: LightsOutPlayer, purpose: create player 2
     * @param n, type: int, purpose: creates game board
     */
    public LightsOut(LightsOutPlayer p1, LightsOutPlayer p2, int n) {
        super(p1,p2);
        board = new int[n][n];
    }

    /**
     * Makes board
     * @return board type: int[][], purpose: returns board
     */
    public int[][] getBoard(int num) {
        board = new int[num][num];
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                board[i][j] = 0;   
            }
        } //filing board with 0
        return board;
    }

    /**
     * randomizes board
     * @return board type: int[][], purpose: returns board
     */
    public int[][] randomize(int[][] board) {
        Random rand = new Random();
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                board[i][j] = rand.nextInt(2);   
            }
        }
        return board;
    }

    /**
     * Presses board (+) changes values
     * @param row, type: int, purpose: x value on board
     * @param col, type: int, purpose: y value on board
     */
    public void press(int row, int col) {
        if (board[row][col] == 1) {
            board[row][col] = 0;
        } else {
            board[row][col] = 1;
        }

        if ((row - 1) >= 0) {
            if(board[row-1][col] == 1) {
                if (board[row - 1][col] == 1) {
                    board[row-1][col] = 0;
                } else {
                    board[row-1][col] = 1;
                }
            }
        }

        if ((row - 1) < board.length) {
            if(board[row+1][col] == 1) {
                if (board[row + 1][col] == 1) {
                    board[row+1][col] = 0;
                } else {
                    board[row+1][col] = 1;
                }
            }
        }

        if ((row - 1) >= 0) {
            if(board[row][col-1] == 1) {
                if (board[row][col - 1] == 1) {
                    board[row][col-1] = 0;
                } else {
                    board[row][col-1] = 1;
                }
            }
        }

        if ((row - 1) < board.length) {
            if(board[row][col+1] == 1) {
                if (board[row][col + 1] == 1) {
                    board[row][col+1] = 0;
                } else {
                    board[row][col+1] = 1;
                }
            }
        }
    }

    /**
     * checks to see if whole board is dark
     * @return isDark type: boolean, purpose: returns isDark
     */
    public boolean isDark(int row, int col) {
        boolean isDark = true;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                if (board[i][j] == 1) {
                    isDark = false;
                }
            }
        }
        return isDark;
    }

    /**
     * Reads out data
     */
    @Override
    public String toString() {
        String result = "#";
        for (int i = 0; i < board.length; i++) {
            System.out.print(i);
            for (int j = 0; j < board[i].length; j++) {
                if (board[i][j] == 1) {
                    result = "x";
                    return result;
                } else {
                    result = "_";
                    return result;
                }
            }
        }
        return result;
    }
}
