
/**
 * Write a description of class Lab3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
import java.math.*;
import java.util.Scanner;
public class Lab3
{
    public static int sumUpEvenRec(int num) {
        int sum = 0;
        int length = String.valueOf(num).length();
        for (int i = 0; i < length; i++) {
            //System.out.print(num + " "); //checking
            sum += num%10;
            num = num/10;
        }
        return sum;
    }
    ///*
    public static int[] findPeakRec(int[][] data, int left, int right) {
        int mid = (left+right)/2;
        int largest = largest(data, mid);
        if (data[largest][mid] < data[largest][mid+1]) {
            left = mid;
            findPeakRec(data, left, right);
        } else if (data[largest][mid] < data[largest][mid-1]) {
            right = mid;
            findPeakRec(data, left, right);
        }
            return data[];
        
    }
    //*/
    public static int largest(int[][] data, int col) {
        int index = 0;
        for (int i = 1; i < data.length; i++) {
            if (data[i][col] > data[index][col]) {
                index = i;
            }
        }
        System.out.println("Largest: " + data[index][col]); //checking largest
        System.out.println("Index: " + index); //checking largest
        return index;
    }

    public static int[][] getRandomDataTable(int size) {
        int [][] array = new int [size][size];
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                array[i][j] = (int)(Math.random()*100);
                System.out.printf("%3d", array[i][j]);
            }
            System.out.println();
        }
        return array;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println(sumUpEvenRec(91827364)); //=40
        System.out.println(sumUpEvenRec(1234)); //=10
        System.out.println(sumUpEvenRec(54321)); //=15

        System.out.println("What size?");
        int size = scan.nextInt();

        int[][] data = getRandomDataTable(size);
        //call recursive method
        int[] peakCoords = findPeakRec(data, 0, size);
        int peakVal = data[peakCoords[0]][peakCoords[1]];
        System.out.println(peakVal + " is a peak at row " + peakCoords[0] + ", col " + peakCoords[1]);
    }  
}
