import java.io.*;
import java.util.*;
/**
 * Reads in data from a text file named in.txt, adds total of int and of totals and outputs them into int and double file.
 *
 * @author Nick Lemerond
 * @version 11/11
 */
public class arrayList
{
    public static void main(String[] args) {
        File inFile = new File("in.txt");

        Scanner in = null;
        PrintWriter out = null;
        try {
            in = new Scanner(inFile);
            List<String> myList = new ArrayList();
            while(in.hasNext()) {
                 myList.add(in.next()); //expensive to front insert
            }
            
            out = new PrintWriter("out_array.txt");
            for (int i = myList.size() - 1; i > 0; i--) {
                out.print(myList.get(i));
            }
            //out.println(myList);
        } catch(IOException e) {
            System.out.println("Something went wrong with the file. Exiting.");
        } finally {
            if(in != null) {
                in.close();
            }
            if(out != null) {
                out.close();
            }
        }

        
    }
}
