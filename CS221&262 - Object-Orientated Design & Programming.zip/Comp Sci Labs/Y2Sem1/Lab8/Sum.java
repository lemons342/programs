import java.io.*;
import java.util.*;
/**
 * Reads in data from a text file named in.txt, adds total of int and of totals and outputs them into int and double file.
 *
 * @author Nick Lemerond
 * @version 11/11
 */
public class Sum
{
    public static void main(String[] args) {
        File inFile = new File("in.txt");

        Scanner in = null;
        PrintWriter out_int = null;
        PrintWriter out_double = null;
        try {
            in = new Scanner(inFile);
            int intTotal = 0;
            double doubleTotal = 0.0;

            while(in.hasNext()) {
                if(in.hasNextInt()) {
                    int currentNum = in.nextInt();
                    intTotal += currentNum;
                } else if (in.hasNextDouble()) {
                    double currentNum = in.nextDouble();
                    doubleTotal += currentNum;
                } else {
                    in.next();
                }
            }

            out_int = new PrintWriter("int_total.txt");
            out_int.println("Int total: " + intTotal);
            out_double = new PrintWriter("double_total.txt");
            out_double.println("Double total: " + doubleTotal);

        } catch(IOException e) {
            System.out.println("Something went wrong with the file. Exiting.");
        } finally {
            if(in != null) {
                in.close();
            }
            if(out_int != null) {
                out_int.close();
            }
            if(out_double != null) {
                out_double.close();
            }
        }

        
    }
}
