import java.io.*;
import java.util.*;
/**
 * Program that converts the Java source code from the next-line brace style to the
 * end-of-line brace style
 * @author Nick Lemerond
 * @version 11/11
 */
public class CopyOfBraceStyle
{
    public static void main(String[] args) {
        File inFile = new File("Test.java");
        BufferedReader reader;

        Scanner in = null;
        PrintWriter out = null;
        try {
            in = new Scanner(inFile);
            reader = new BufferedReader(new FileReader("Test.java"));
            String newlineCode = reader.readLine();
            out = new PrintWriter("Test_newlinebraces.java");
            while(newlineCode != null) {
                if (newlineCode == "Test") {
                    out.println("Test_newlinebraces");
                    newlineCode = reader.readLine();
                } else {
                    out.println(newlineCode);
                    newlineCode = reader.readLine();
                }
                /*
                if(in.hasNext() = ";") {
                newlineCode += "\n";
                } else {
                newlineCode += in.nextLine();
                }
                 */
            }
            reader.close();

        } catch(IOException e) {
            System.out.println("Something went wrong with the file. Exiting.");
        } finally {
            if(in != null) {
                in.close();
            }
            if(out != null) {
                out.close();
            }
        }

    }
}
