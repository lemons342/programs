import java.io.*;
import java.util.*;
/**
 * Program that converts the Java source code from the next-line brace style to the
 * end-of-line brace style
 * @author Nick Lemerond
 * @version 11/11
 */
public class BraceStyle
{
    public static void main(String[] args) {
        File inFile = new File("Test.java");

        Scanner in = null;
        PrintWriter out = null;
        try {
            in = new Scanner(inFile);
            String newlineCode = "";
            out = new PrintWriter("Test_newlinebraces.java");
            while(in.hasNext()) {
                if(in.hasNext()) {
                    newlineCode = "\n";
                    out.println(newlineCode);
                } else {
                    newlineCode = in.nextLine();
                    out.println(newlineCode);
                }
            }

        } catch(IOException e) {
            System.out.println("Something went wrong with the file. Exiting.");
        } finally {
            if(in != null) {
                in.close();
            }
            if(out != null) {
                out.close();
            }
        }

        
    }
}
