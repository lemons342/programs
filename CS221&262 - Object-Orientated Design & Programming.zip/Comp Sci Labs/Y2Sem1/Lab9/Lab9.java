/**
 * FLAWED methods for various utilities
 */
public class Lab9
{   
    /**
     * Method to determine the perfect square of a given number
     * or -1 if the number isn't a perfect square
     *
     * @param num - number to find perfect square of
     * @return The perfect square of the number, or -1 if not a perfect square
     */
    public static int perfectSquare(int num) {
        int sqRoot = (int) Math.sqrt(num);
        return num % sqRoot == 0 ? sqRoot : -1;
    }

    /**
     * Determines if the given String array is in alphabetical order
     *
     * @param items to determine if in alphabetical order
     * @return true if the items are in alphabetical order, false if not
     */
    public static boolean inAlphabeticalOrder(String[] items) {
        boolean comesBefore = true;

        int i = 1;
        while(comesBefore && i < items.length) {
            comesBefore = items[i-1].charAt(0) <= items[i].charAt(0);
            i++;
        }

        return comesBefore;
    }
    
    /**
     * An identity matrix is a square matrix 
     * with values of 1 on the diagonal and 0 everywhere else.
     * This method determines if a given array is an identity matrix.
     *
     * @param matrix 
     * @return true if the matrix is an identity matrix, false if not
     */
    public static boolean isIdentityMatrix(int[][] matrix) {
        boolean isIDMatrix = true;

        int row = 0;
        while(isIDMatrix && row < matrix.length) {
            int col = 0;
            while(isIDMatrix && col < matrix[row].length) {
                if(row == col) {
                    isIDMatrix = matrix[row][col] == 1;
                }
                col++;
            }
            row++;
        }

        return isIDMatrix;
    }
}
