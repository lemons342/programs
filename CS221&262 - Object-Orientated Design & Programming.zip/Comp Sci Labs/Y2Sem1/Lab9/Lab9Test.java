
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class Lab9Test.
 *
 * @author  Nick Lemerond
 * @version 11/22
 */
public class Lab9Test
{
    /**
     * Default constructor for test class Lab9Test
     */
    public Lab9Test()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        //System.out.println("Setting up");
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testPerfectSquare() {
        Lab9 test = new Lab9();
        test.perfectSquare(9);
        test.perfectSquare(8);
        test.perfectSquare(-1);
        test.perfectSquare(0);
    }

    @Test
    public void testAlphabeticalOrder() {
        Lab9 test = new Lab9();
        String[] items1 = {"alphabet", "computer", "science", "lab9"};
        assert (test.inAlphabeticalOrder(items1) == false) : "Assertion failed - method fails to work";
        String[] items2 = {"9lab", "alphabet", "computer", "science"};
        assert (test.inAlphabeticalOrder(items2) == false) : "Assertion failed - number in beginning of string";
        String[] items3 = {" alphabet", "zero", ","};
        assert (test.inAlphabeticalOrder(items3) == false) : "Assertion failed - comma in string";
        String[] items4 = {"alphabet", "bananas", "computers", "davidfurcy"};
        assert (test.inAlphabeticalOrder(items4) == true) : "Assertion failed - method fails to work";
    }

    @Test
    public void testIsMatrix() {
        Lab9 test = new Lab9();
        int[][] matrix1 = {{1,4,5},{9,8,7},{23,65,59}};
        assert (test.isIdentityMatrix(matrix1) == false) : "Assertion failed - method fails to work";
        int[][] matrix2 = {{1,0,0},{0,1,0},{0,0,1}};
        assert (test.isIdentityMatrix(matrix2) == true) : "Assertion failed - method fails to work";
        int[][] matrix3 = {{1,0,0},{0,1,0},{0,0,1,0}};
        assert (test.isIdentityMatrix(matrix3) == false) : "Assertion failed - not square matrix";
        int[][] matrix4 = {{-1,0,0},{0,1,0},{0,0,1}};
        assert (test.isIdentityMatrix(matrix4) == false) : "Assertion failed - Negative integer";
        test.isIdentityMatrix(matrix4);
    }
}
