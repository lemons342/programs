
/**
 * Write a description of class Lab2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Lab2
{
    public static boolean isPalindromeRec(String str) {
        boolean pal;
        if(str.length() <= 1) { //palindrome is length gets to 0 or 1
            return true;
        } if (str.charAt(0) == str.charAt(str.length() - 1)) { //if still is palindrome keep going through recursion
            return isPalindromeRec(str.substring(1, str.length()-1));
        }
        return false; //returns false if none of the if statement are met
    }

    public static String reverseRec3(String str) {
        String reverse;
        if(str.length() <= 1) {
            reverse = str;
        } else if(str.length() % 3 == 0){ //if string is divisible by 3
            int firstThird = str.length() / 3; //splits string into thirds
            int secondThird = (str.length() / 3) + (str.length() / 3);
            reverse = reverseRec3(str.substring(secondThird)) + reverseRec3(str.substring(firstThird, secondThird)) + reverseRec3(str.substring(0, firstThird));
        } else { //if not divisible by 3
            int lastIndex = str.length()-1;
            reverse = str.charAt(lastIndex) + reverseRec3(str.substring(0, lastIndex));
        }
        return reverse;
    }

    public static void main(String[] args) {
        System.out.println(reverseRec3("ilovecode"));
        System.out.println(reverseRec3("FunWithRecursive"));
        System.out.println(reverseRec3("JavaIsGreat"));
        System.out.println(isPalindromeRec("racecar"));
        System.out.println(isPalindromeRec("tacocat"));
        System.out.println(isPalindromeRec("notapalindrome"));
    }
}
