import java.util.*;
/**
 * Program to let a user practice sorting fractions
 *
 * @author Nick Lemerond
 * @version 11/1
 */
public class Driver
{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int numFracs;
        Fraction[] fractions = {};

        // Prompt the user for the number of fractions to practice with
        System.out.print("How many fractions? ");
        numFracs = 0;
        boolean gotInput = false;
        while (!gotInput) {
            try {
                numFracs = in.nextInt(); 
                gotInput = true;
            } catch(InputMismatchException e) {
                System.out.println("You must enter ints");
                in.nextLine();
            }
        }
        // Initialize the fraction array for the number of fractions given by the user
        gotInput = false;
        while (!gotInput) {
            try {
                fractions = new Fraction[numFracs];
                gotInput = true;
            }  catch(NegativeArraySizeException e) {
                System.out.println("You must enter positive number of fractions, try again");
                numFracs = in.nextInt(); 
            }
        }
        // (TODO-Incomplete) Prompt the user for each fraction
        for (int i = 0; i < numFracs; i++) {
            System.out.println("Enter Fraction " + (i+1));
            gotInput = false;
            int numerator = 0;
            int denominator = 0;
            while (!gotInput) {
                try {
                    System.out.print("Numerator: ");
                    numerator = in.nextInt();
                    System.out.print("Denominator: ");
                    denominator = in.nextInt();
                    gotInput = true;
                } catch(InputMismatchException e) {
                    System.out.println("You must enter integer values, try again");
                    in.nextLine();
                }
            }
            // Save the user-entered fraction in the array
            fractions[i] = new Fraction(numerator, denominator);
        }

        // ALL CODE BELOW THIS POINT IS "DONE" EXCEPT FOR EXCEPTION HANDLING
        // Create the "answer" the user is trying to get by
        // creating a copy of the fraction array and sorting it
        Fraction[] sortedFractions = fractions.clone();
        try {
            Arrays.sort(sortedFractions);
        } catch (ClassCastException e) {
            System.out.println("ClassCastException");
        }

        // While the user's array isn't sorted (while it doesn't equal the sorted answer)
        while(!Arrays.equals(fractions,sortedFractions)) {
            // Print the current version of the array
            System.out.println();
            System.out.println(Arrays.toString(fractions));

            // Promt the user for which fractions to swap
            // Assume the user considers the first fraction to be 1 (not 0)
            gotInput = false;
            int fractionIndex1 = 0;
            int fractionIndex2 = 0;
            while (!gotInput) {
                try {
                    System.out.println("Which two fractions would you like to swap?");
                    System.out.print("Swap Fraction: ");
                    fractionIndex1 = in.nextInt() - 1; // subtract 1 to zero index
                    System.out.print("with Fraction: ");
                    fractionIndex2 = in.nextInt() - 1; // subtract 1 to zero index
                    gotInput = true;
                } catch(InputMismatchException e) {
                    System.out.println("You must enter integer values, try again");
                    in.nextLine();
                } 
            }
            // Swap the two fractions
            gotInput = false;
            while (!gotInput) {
                try {
                    Fraction temp = fractions[fractionIndex1];
                    fractions[fractionIndex1] = fractions[fractionIndex2];
                    fractions[fractionIndex2] = temp;
                } catch(IndexOutOfBoundsException e) {
                    System.out.println("Invalid fraction index, try again");
                    in.nextLine();
                } 
            }

            System.out.println();
            System.out.println("Good job! Final Sorted Array:");
            System.out.println(Arrays.toString(fractions));
        }
    } 
}
