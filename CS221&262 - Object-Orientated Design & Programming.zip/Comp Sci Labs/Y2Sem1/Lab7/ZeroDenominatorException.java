
/**
 * Write a description of class ZeroDenominatorException here.
 *
 * @author Nick Lemerond
 * @version 11/1
 */
public class ZeroDenominatorException extends java.lang.Exception {
    public ZeroDenominatorException() {
        if (denominator == 0) {
            throw new ZeroDenominatorException("Zero is an invalid denominator");
        }   
    }
}
