
/**
 * Fraction
 *
 * @author Nick Lemerond
 * @version 11/1
 */
public class Fraction
{
    /** Numerator */
    private int numerator;
    /** Denominator */
    private int denominator;

    /**
     * Default Constructor 
     * Default Fraction: 1/1
     */
    public Fraction() {
        this.numerator = 1;
        this.denominator = 1;
    }

    /**
     * Fraction Constructor
     *
     * @param numerator Value to be the numerator
     * @param denominator Value to be the denominator
     */
    public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    /**
     * Get the numerator of the fraction
     *
     * @return The numerator
     */
    public int getNumerator() {
        return numerator;
    }

    /**
     * Set the numerator to be the given value
     *
     * @param numerator New numerator value
     */
    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }

    /**
     * Get the denominator of the fraction
     *
     * @return The denominator
     */
    public int getDenominator() {
        return denominator;
    }
    
    /**
     * Set the denominator to be the given value
     *
     * @param denominator New denominator value
     */
    public void setDenominator(int denominator) {
        this.denominator = denominator;
    }
    
    /**
     * Reads out data
     */    
    @Override
    public String toString() {
        String result = numerator + "/" + denominator;
        return result;
    }
} 
