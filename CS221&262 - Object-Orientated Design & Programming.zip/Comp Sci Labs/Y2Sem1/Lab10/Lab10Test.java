
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Lab10Test
{
    /* ---------- TESTS FOR digitAt ----------*/
    /* digitAt should take a number (int) and a 
     * "place" (1s, 10s, 100s, etc.) given as an int
     * and return the digit in the number at that place
     */
    
    @Test 
    public void test01() {
        assertEquals(3, Lab10.digitAt(1023,1));
    }
    
    @Test
    public void test02() {
        assertEquals(2, Lab10.digitAt(1023,10));
    }
    
    @Test
    public void test03() {
        assertEquals(0, Lab10.digitAt(1023,100));
    }
    
    @Test
    public void test04() {
        assertEquals(1, Lab10.digitAt(1023,1000));
    }
    
    @Test
    public void test05() {
        assertEquals(0, Lab10.digitAt(1023,10000));
    }
    
    @Test
    public void test06() {
        assertEquals(2, Lab10.digitAt(-1023,10));
    }
    
    @Test
    public void test07() {
        assertEquals(0, Lab10.digitAt(-23,100));
    }
    
    @Test
    public void myTest01() {
        assertEquals(1, Lab10.digitAt(-1,1));
    }
    
    /* ---------- TESTS FOR maxElement ----------*/
    /* maxElement should take an array of items
     * and return the max element from that array of items
     */
    
    @Test
    public void test08() {
        Integer[] myInts = {6, 2, 10, 5, 1};
        Integer expected = 10;
        assertEquals(expected, Lab10.maxElement(myInts));
    }
    
    @Test
    public void test09() {
        Integer[] myInts = {Integer.MAX_VALUE, 2, 6, 5, 1};
        Integer expected = Integer.MAX_VALUE;
        assertEquals(expected, Lab10.maxElement(myInts));
    }
    
    @Test
    public void test10() {
        Double[] myDoubles = {null, 2.1, 10.1, 5.6, 10.2};
        Double expected = 10.2;
        assertEquals(expected, Lab10.maxElement(myDoubles));
    }
    
    @Test
    public void test11() {
        Integer[] myInts = {-6, -2, -1, -5, -10};
        Integer expected = -1;
        assertEquals(expected, Lab10.maxElement(myInts));
    }
    
    @Test
    public void test12() {
        Integer[] myInts = {-6, 2, 1, -5, -10};
        Integer expected = 2;
        assertEquals(expected, Lab10.maxElement(myInts));
    }
    
    @Test
    public void test13() {
        Integer[] myInts = {-6};
        Integer expected = -6;
        assertEquals(expected, Lab10.maxElement(myInts));
    }
    
    @Test
    public void test14() {
        String[] myStrings = {"frosty", "the", "snowman", "happy", "birthday"};
        String expected = "the";
        assertEquals(expected, Lab10.maxElement(myStrings));
    }
    
    @Test
    public void test15() {
        String[] myStrings = {"frosty", null, "happy", null, "birthday"};
        String expected = "happy";
        assertEquals(expected, Lab10.maxElement(myStrings));
    }
    
    @Test
    public void test16() {
        String[] myStrings = {};
        String expected = null;
        assertNull(expected, Lab10.maxElement(myStrings));
    }
    
    @Test
    public void myTest02() {
        Integer[] myInts = {1 , -2, -3, -4, -5};
        Integer expected = 1;
        assertEquals(expected, Lab10.maxElement(myInts));
    }
}
