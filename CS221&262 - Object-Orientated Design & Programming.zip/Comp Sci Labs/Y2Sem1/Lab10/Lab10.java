import java.lang.Math;
/**
 * Making methods so the tests don't give error 
 *
 * @author Nick Lemerond
 * @version 12/4
 */
public class Lab10
{
    public static int digitAt(int num, int place) {
        int digit = -1;

        for (int i = 1; i <= place; i*=10) {
            digit = num % 10; 
            num = num / 10;
        }
        return Math.abs(digit);
    }

    public static <TheType extends Comparable<TheType>> TheType maxElement(TheType... array) {
        TheType max = null;
        if (array.length != 0) {
            max = array[0];
            for (TheType element: array) {
                if ((element.compareTo(max) > 0)) {
                    max = element;
                }
            }
        }
        return max;
    }
}
