import java.io.*;
import java.util.*;
/**
 * Takes in a bas file. Changes the line numbers to user inputed numbers and also 
 * changes the jump line numbers to their appropriate lines
 *
 * @author Nick Lemerond, Sam Sasin
 * @version 12/13
 */
public class Project4
{
    public static void main(String[] args) {
        String file = args[0]; 
        int start = Integer.parseInt(args[1]);
        int inc = Integer.parseInt(args[2]); // takes file, start number, and increment from command line

        File inFile = new File(file);
        Scanner in = null;
        PrintWriter out = null;
        try {
            in = new Scanner(inFile);
            HashMap<Integer, String> map = new HashMap<>();
            while(in.hasNextLine()) {
                int num = in.nextInt(); //pull out first number of each line
                String line = num + "" + in.nextLine(); //grab the rest of the line but add the number to the begginning
                map.put(num, line); //put the string in the hasmap at the line location from the bas file
            }
            out = new PrintWriter(file + "Output.txt");
            TreeMap<Integer, String> treeMap = new TreeMap<>(map); //put hashmap in treemap to sort

            changeNumbers(treeMap, start, inc);

            //printing each line
            for (int i = 0; i <= treeMap.lastKey(); i++) {
                if (treeMap.containsKey(i)) { //loops i and only does anything when treeMap contain a key at i
                    String modifyLine = treeMap.get(i);
                    if (modifyLine.contains("GO TO") || modifyLine.contains("THEN") || modifyLine.contains("GOSUB")) {
                        int keyChange = grabJumpLine(modifyLine); //grabs the line number that the code is jumping to

                        modifyLine = removeJumpLine(modifyLine) + "" + grabLine(treeMap.get(keyChange));
                    }  
                    out.println(modifyLine);
                } 
            }    
            
        } catch(InputMismatchException e) { 
            System.out.println("InputMismatchException. Exiting.");
        } catch(ArithmeticException e) {
            System.out.println("ArithmeticException. Exiting.");
        } catch (NullPointerException ex) { 
            System.out.println("NullPointerException. Exiting.");
        } catch (RuntimeException ex) {
            System.out.println("RuntimeException. Exiting.");
        } catch(IOException e) {
            System.out.println("Something went wrong with the file. Exiting.");
        } finally {
            if(in != null) {
                in.close();
            }
            if(out != null) {
                out.close();
            }
        }
    }

    private static void changeNumbers(TreeMap<Integer, String> mapToUpdate, int starter, int adder) {
        int increment = starter;
        Set<Map.Entry<Integer,String>> entries = mapToUpdate.entrySet();
        for(Map.Entry<Integer,String> curEntry : entries) {
            mapToUpdate.put(curEntry.getKey(), modifyInt(curEntry.getValue(), increment)); //putting the modified string in the incremented location
            increment += adder;
        }
    }

    private static String modifyInt(String line, int num) {
        Scanner find = new Scanner(line); //scans the string
        find.nextInt(); //finds the line number and passes it
        String newLine = (num) + "" + find.nextLine();
        return newLine; //returns line with new line number
    }

    private static int grabJumpLine(String line) {
        Scanner find = new Scanner(line); //scans the string
        int lineNum = -1;
        while(find.hasNext()) {
            String temp = find.next(); //for some reason i have to do this otherwise it's an infinite loop
            if (find.hasNextInt()) {
                lineNum = find.nextInt();
            }
        }
        return lineNum; //returns the jump line number
    }

    private static String removeJumpLine(String line) {
        Scanner find = new Scanner(line); //scans the string
        int lineNum = -1;
        String newLine = "";
        boolean ifthen = false;
        if (line.contains("IF")) { // also when newLine.contains("THEN")
            ifthen = true;
        } 
        while(find.hasNext()) {
            String temp = find.next(); //for some reason i have to do this otherwise it's an infinite loop
            if (find.hasNextInt()) {
                if (!ifthen) { 
                    lineNum = find.nextInt();//this will run when the jump string has 3 ints (in the case of a ifthen) so when it is ifthen, it is skipped once so that it prints properly
                }
                ifthen = false; //next nextInt after this will be the jumpLine
            }

            newLine += temp + " "; //adds the next scanned string excluding the jumpLine
        }
        return newLine; //returns the line without the jumpLine
    }

    private static int grabLine(String line) {
        Scanner find = new Scanner(line); //scans the string
        int lineNum = find.nextInt(); //finds the lineNumber
        return lineNum; // reutnrs the line number
    }
}
