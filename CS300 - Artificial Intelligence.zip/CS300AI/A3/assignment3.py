
from search import Problem
from csp import backtracking_search, no_inference, forward_checking, mac
from csp import first_unassigned_variable,mrv,num_legal_values,unordered_domain_values,lcv
from csp import CSP,usa,france,australia,NQueen,UniversalDict
import math,random

#______________________________________________________________________________

file = 'b1.txt'

vars = []
neighbors = {}
domains = {}
boardSize = 0
with open(file, 'r') as f:
    lines = f.readlines()
    boardSize = len(lines)  #get board size
    #-----------------------------------------
    def getDomains(list): #takes in row/col values
        allDomains = []
        #copy = list.copy()
        maxSum = boardSize/2
        variable = [0] * boardSize
        lookUp = []
        objects = boardSize

        k=0
        for x in list:  #checking for locked tiles
            if x == 'B':
                lookUp.append(k)
                objects-=1
            if x == 'R':
                variable[k] = 1
                lookUp.append(k)
                maxSum-=1
                objects-=1
            k+=1
        combinations = math.factorial(objects) / (2*(math.factorial(objects-2))) #nCr
        while(len(allDomains) <= combinations): #creating domains
            temp = variable.copy()
            listSum = maxSum
            for k in range(boardSize):  #algorithm for assigning values to empty tiles(has issues i think)
                if (k not in lookUp) and (listSum > 0):
                    if listSum > 0:
                        temp[k] = 1
                        listSum-=1
                    if temp in allDomains: 
                        temp[k] = 0
                        listSum+=1
            allDomains.append(temp)

        temp = allDomains.copy()
        for item in temp:
            if sum(item) != boardSize/2: #preprocessing (same number of red and blue tiles)
                allDomains.remove(item)
            else:                        #preprocessing (no more than two red or two blue consecutive tiles)
                size = len(item)
                remove = 0  #boolean
                for i in range(size-2):
                    if item[i] == item[i+1] and item[i+1] == item[i+2] and remove == 0:
                        remove = 1
                if remove == 1:
                    allDomains.remove(item)
        return allDomains #returns all domains after preprocessing
    #-----------------------------------------
    rowTemp = []
    colTemp = []
    for i in range(boardSize):
        vars.append('R' + str(i+1)) #all row variables declared
        rowTemp.append(vars[i])
    for i in range(boardSize):   
        vars.append('C' + str(i+1)) #all col variables declared
        colTemp.append(vars[i + boardSize])
    varSize = len(vars)
    for i in range(varSize):
        temp = vars.copy()
        temp.remove(vars[i])
        neighbors[vars[i]] = temp   #all neighbors declared
    i = 0
    for line in lines:      
        temp = list(line.strip())
        domains[vars[i]] = getDomains(temp) #row domains declared
        i+=1
    for j in range(boardSize):
        temp = []
        k = 0 
        for line in lines:
            if line[j] == '-':
                temp.append(line[j])
            if line[j] == 'B':
                temp.append(line[j])
            if line[j] == 'R':
                temp.append(line[j])
            k+=1
        domains[vars[i]] = getDomains(temp) #column domains declared
        i+=1

#print("boardSize:", boardSize)
#print("vars")
#print(vars)
#print("neighbors")
#print(neighbors)
#print("domains")
#print(domains)
 

# takes in variables and the two current values for those variables 38:50
def a3_constraints(A, a, B, b):
    #R(n) <> R(m)  or  C(n) <> C(m)
    if (A[0]==B[0]): return (a != b)  
    #R[n](m) == C[m](n)  or  C[m](n) == R[n](m)
    if (A[0]=='R' and B[0]=='C') or (A[0]=='C' and B[0]=='R'): return (a[int(B[1])-1] == b[int(A[1])-1])  

def printTable(results):
    if (results != None):
        for key in results:
            board = ''
            if key[0] == 'R': #print rows
                row = results[key]
                for val in row:
                    if val == 0: board+='B'
                    if val == 1: board+='R'
                print(board)
        
#______________________________________________________________________________
problem = CSP(vars, domains, neighbors, a3_constraints)  
result = backtracking_search(problem,inference=mac) #no_inference forward_checking mac

print("result:", result)
printTable(result)