from search import Problem, Node
from utils import probability, argmax, argmin_list, argmax_random_tie, weighted_sample_with_replacement, weighted_sampler
import random

#______________________________________________________________________________
#Hill climbing
#You can make changes to the algorithm below, as needed.
#You will need to add a helper method that calls this method. That helper method will do the random restart.
def hill_climbing(problem):
    """From the initial node, keep choosing the neighbor with highest value,
    stopping when no neighbor is better."""
    current = Node(problem.initial)
    #print("problem.initial",problem.initial)
    restarts = 0
    steps = 0
    while restarts < 1000:
        steps +=1
        neighbors = current.expand(problem)
        if not neighbors:
            break

        neighbor = argmax_random_tie(neighbors,
                                     lambda node: problem.value(node.state))
        if problem.value(neighbor.state) == (problem.size(neighbor.state)*(problem.size(neighbor.state)-1)):
            #print("hit termination:", neighbor.state)
            addHillData(steps, problem.value(neighbor.state))
            return neighbor.state

        elif problem.value(neighbor.state) <= problem.value(current.state):
            current = random_restart(problem.value(current.state), problem.size(current.state))
            #print("local max...restart:", current.state)
            restarts+=1
            #print("restarts",restarts)
        
        elif problem.value(neighbor.state) > problem.value(current.state):
            current = neighbor
            #print("choose neighbor:", current.state)

    
    addHillData(steps, problem.value(current.state))
    return current.state #if value = size*(size-1) then 

local_max_values = []
def random_restart(stateValue, size):
    local_max_values.append(stateValue)

    randomState = []
    for i in range(size):
        randomState.append(random.randrange(size)+1)
    #print("Node(randomState)", Node(randomState))
    return Node(NQueenProblem(NQueenState(randomState)).initial)

def random_instance(size):
    '''
    problemInstances = []

    for i in range(20):
        randomInstance = []
        for j in range(size):
            randomInstance.append(random.randrange(size)+1)
        problemInstances.append(randomInstance)

    f = open("test.xlsx", "w")
    f.write(str(problemInstances))
    f.close()

    #print("problemInstances:",problemInstances)
    '''
    f = open("instances.txt", "w")
    for i in range(20):
        for j in range(size):
            f.write(str(random.randrange(size)+1))
            if j != size-1:
                f.write(',')
        f.write('\n')
    f.close()

instanceNumberHill = 0
def addHillData(steps, value):
    global instanceNumberHill
    instanceNumberHill += 1
    f = open("hillclimbingData.txt", "a")
    f.write("Instance #")
    f.write(str(instanceNumberHill))
    f.write('\n')
    f.write(str(steps))
    f.write('\n')
    f.write(str(value/2)) #(n*(n-1))/2
    f.write('\n')
    f.close


#Genetic algorithms
#You can make changes to the algorithm below, as needed
def genetic_search(problem, fitness_fn, ngen=1000, pmut=0.1):
    """Call genetic_algorithm on the appropriate parts of a problem.
    This requires the problem to have states that can mate and mutate,
    plus a value method that scores states.
    """
    s = problem.initial
    #You may want to change this to increase the population size in general
    states = [problem.result(s, a) for a in problem.actions(s)]
    random.shuffle(states)
    return genetic_algorithm(states, problem.value, ngen, pmut)

#You can make changes to the algorithm below, as needed
def genetic_algorithm(population, fitness_fn, ngen=1000, pmut=0.1):
    global boardSize
    highest = 0
    generations = 0
    highestEvolved = None

    for i in range(ngen):
        new_population = []
        for j in range(len(population)): #decide size of population appropriately
            fitnesses = map(fitness_fn, population)
            
            p1, p2 = weighted_sample_with_replacement(population, fitnesses, 2) #selection scheme
            child = p1.mate(p2)
            if random.uniform(0, 1) < pmut: #mutation
                child.mutate()
            new_population.append(child)
        population = new_population
        
        #Check and keep track of max; not necessarily pure GA
        #Add i and n returned
        #selection scheme
        currentEvolved = argmax(population, fitness_fn)
        currentHigh = fitness_fn(currentEvolved)
        if currentHigh > highest:    
            highest = currentHigh
            highestEvolved = currentEvolved
        generations += 1
        if currentHigh == boardSize*(boardSize-1):  #early termination
            break
    addGeneticData(generations, currentHigh) #add data
    return highestEvolved
    
    #Pure GA might return this instead        
    #return argmax(population, fitness_fn)
instanceNumberGen = 0
def addGeneticData(generations, value):
    global instanceNumberGen
    instanceNumberGen += 1
    f = open("geneticesearchData.txt", "a")
    f.write("Instance #")
    f.write(str(instanceNumberGen))
    f.write('\n')
    f.write(str(generations))
    f.write('\n')
    f.write(str(value/2)) 
    f.write('\n')
    f.close
    
class GAState:
    "Abstract class for individuals in a genetic search."
    def __init__(self, genes):
        self.genes = genes

    def mate(self, other):
        "Return a new individual crossing self and other."
        c = random.randrange(len(self.genes))
        return self.__class__(self.genes[:c] + other.genes[c:])

    def mutate(self):
        "Change a few of my genes."
        raise NotImplementedError

    def __repr__(self):
        return "%s" % (self.genes,)
    
    #override if this is not what you want
    def __eq__(self,other):
        return isinstance(other, GAState) and self.genes == other.genes
 
#______________________________________________________________________________
#NQueenProblem and NQueenState
class NQueenState(GAState):
    '''
    special state for genetic algorithms, extends from GAState NQueen problem
    genes is the state for regular problems, wrapped in GAState child for this version
    Override the methods you are interested in.
    '''
    def __init__(self, genes):
        GAState.__init__(self, genes)

    def mutate(self):
        #flip a random bit
        c = random.randrange(len(self.genes))
        self.genes[c] = 1 - self.genes[c]
        
class NQueenProblem(Problem):
    '''
    The problem of placing N queens on an NxN board with none attacking
    each other.  The problem can be initialized to some random, non-viable state.
    Recall that the states (init, etc.) are all NQueenState objects, so the genes 
    in the state are represented as an N-element array, where
    a value of r in the c-th entry means there is a queen at column c,
    row r. Keeps track of the number of steps too.
    '''
    def __init__(self, init): #, N
        #self.N = N
        self.initial = init

    def actions(self, state):
        '''
        Implement this method.
        Returns the neighbors of a given state. You must implement this so that the
        neighbors are from the "neighborhood" and are not an enormous set.
        '''
        board = list(state.genes)
        neighbors=[]
        #i=0
        #print("Astate", state)
        #print("board", board)
        for i in range(len(board)):
            if ((board[i]-1) > 0):
                temp = list(state.genes)
                temp[i] = (board[i]-1)
                neighbors.append(temp)
            if ((board[i]+1) <= len(board)):
                temp = list(state.genes)
                temp[i] = (board[i]+1)
                neighbors.append(temp)
        #print("neighbors", neighbors)
        return neighbors

        raise NotImplementedError
    
    def result(self, state, action):
        ''' Modify this if your result state is different from your action'''
        return NQueenState(action)

    def value(self, state):
        '''
        Implement this method.
        Assigns a value to a given state that represents the number of non-conflicts.
        The higher the better with the maximum being (n*(n-1))/2 
        Remember, you must look at state.genes
        '''
        board = state.genes
        value = 0
        
        for i in range(len(board)):
            for j in range(len(board)):
                if (i != j) and (board[i] != board[j]) and (board[i] - (i+1)) != (board[j] - (j+1)) and (board[i] + (i+1)) != (board[j] + (j+1)):
                    value += 1 
        '''
               # ^^^ more simplified vvv
                if (board[i] != board[j]):
                    value += 1
                if (board[i] - (i+1)) != (board[j] - (j+1)):
                    value += 1
                if (board[i] + (i-1)) != (board[j] + (j-1)):
                    value += 1
        '''

        #print("board: value", board, value)
        return value

        raise NotImplementedError

    def conflict(self, row1, col1, row2, col2):   #never used 
        '''
        Utility method. You can use this in other methods.
        Would putting two queens in (row1, col1) and (row2, col2) conflict?
        '''
        return (row1 == row2 ## same row
                or col1 == col2 ## same column
                or row1-col1 == row2-col2  ## same \ diagonal
                or row1+col1 == row2+col2) ## same / diagonal

    def size (self, state):
        return len(state.genes)
'''
    def random (self, problem):
        randomState = []
        size = problem.size(problem.initial)
        for i in range(size):
            randomState.append(random.randrange(size+1))
            return randomState
'''
#______________________________________________________________________________
#ExampleProblem and ExampleState
class ExampleState(GAState):
    '''
    Example that does really nothing; just illustrates the process
    '''
    def __init__(self, genes):
        GAState.__init__(self, genes)

    def mutate(self):
        #flip a random bit
        c = random.randrange(len(self.genes))
        self.genes[c] = 1 - self.genes[c]

class ExampleProblem(Problem):
    '''
    An example problem with a list of bits as a list
    '''
    def __init__(self, init):
        self.initial = init

    def actions(self, state):
        '''
        Generate randomly flip one bit; do this twice to generate 2 neighbors
        Actions are just the genes
        '''
        choices=[]
        for i in range(2):
            candidate = list(state.genes)
            c = random.randrange(len(candidate))
            if probability(0.5):
                candidate[c] = 1 - candidate[c]
            choices.append(candidate)           
        return choices
    
    def result(self, state, action):
        ''' Wrap the action genes in an ExampleState and return that'''
        return ExampleState(action)

    def value(self, state):
        '''
            Simply counts number of 1's and returns 1 + that value; 
            We want to avoid  fitnesses of 0 always.
        '''
        return state.genes.count(1) + 1

         
#______________________________________________________________________________
boardSize = 12
def main(): 
    print("Starting...")
    '''
    board = [1,2,3,4] 
    gp = NQueenProblem(NQueenState(board)) 
    print("gp", gp)
    goal = hill_climbing(gp)
    print("Goal = ",goal)   
    print("local max state values", local_max_values)
    '''
    
    ###random_instance(boardSize)  #create instances with board size = boardSize


    with open("instances.txt", 'r') as f:
        instances = [] 
        for line in f:
            instances.append([int(x) for x in line.split(",")]) #read back instances from file
    #print(instances)

    f = open("hillclimbingData.txt", "w")   #create data file
    f.close

    print("Working on hillclimbing...")
    #for j in range(20): #20 instances                  #|removed for submission
    gp = NQueenProblem(NQueenState(instances[1]))       #|changed j to 1, removed indentation
    goal = hill_climbing(gp)                            #|removed indentation
 
    f = open("geneticesearchData.txt", "w") #create data file
    f.close

    print("Working on genetic search...")
    #for j in range(20): #20 instances                  #|removed for submission vvv
    gp = NQueenProblem(NQueenState(instances[1]))       #|changed j to 1, removed indentation
    goal = genetic_search(gp, NQueenProblem.value, ngen=1000, pmut=0.1)#|removed indentation

    print("Done")

main()