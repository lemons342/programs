"""
V1.0
"""
from search import Problem, breadth_first_search,depth_first_search, iterative_deepening_search

#______________________________________________________________________________
#Problem 1
# Tuple format = [<Node (eightLiter,fiveLiter,threeLiter)>]
class JUG(Problem):
    #state is a tuple(eightLiter, fiveLiter, threeLiter) with initial value (8,0,0)
    eightCurrent=0; fiveCurrent=1; threeCurrent=2;  #class "constants"
    
    def __init__(self, initState,goalState):
    	Problem.__init__(self, initState, goalState)
    
    def actions(self, state):     
        # In this kind of simple example, it is common to use the new state itself as the action, 
        # because it is straightforward and more efficient.
        # We don't do that here just to illustrate how we can denote actions separately from states, if so desired.
        
        # list of descriptive actions
        list=[]
        #temp variables for clarity:
        eightLiter, fiveLiter, threeLiter = state[JUG.eightCurrent], state[JUG.fiveCurrent], state[JUG.threeCurrent]
        

        #5from8Lto5L - can we scoop 5 liters from 8L to 5L?
        if self.validate(eightLiter-5, fiveLiter+5, threeLiter):
            list.append("5from8Lto5L")
                
        #3from8Lto3L - can we scoop 3 liters from 8L to 3L?
        if self.validate(eightLiter-3, fiveLiter, threeLiter+3):
            list.append("3from8Lto3L") 
                
        #3from5Lto3L - can we scoop 3 liters from 5L to 3L?
        if self.validate(eightLiter, fiveLiter-3, threeLiter+3):
            list.append("3from5Lto3L")  
        
        #5from5Lto8L - can we dump 5 liters from 5L to 8L?
        if self.validate(eightLiter+5, fiveLiter-5, threeLiter):
            list.append("5from5Lto8L")
            
        #3from3Lto8L - can we dump 3 liters from 3L to 8L?
        if self.validate(eightLiter+3, fiveLiter, threeLiter-3):
            list.append("3from3Lto8L")

        #3from3Lto5L - can we dump 3 liters from 3L to 5L?
        if self.validate(eightLiter, fiveLiter+3, threeLiter-3):
            list.append("3from3Lto5L") 
        

        #Fill8Lfrom5L - can we fill 8L from 5L?
        if self.validate(eightLiter+(8-eightLiter), fiveLiter-(8-eightLiter), threeLiter):
            list.append("Fill8Lfrom5L")

        #Fill8Lfrom3L - can we fill 8L from 3L?
        if self.validate(eightLiter+(8-eightLiter), fiveLiter, threeLiter-(8-eightLiter)):
            list.append("Fill8Lfrom3L")

        #Fill5Lfrom8L - can we fill 5L from 8L?
        if self.validate(eightLiter-(5-fiveLiter), fiveLiter+(5-fiveLiter), threeLiter):
            list.append("Fill5Lfrom8L")

        #Fill5Lfrom3L - can we fill 5L from 3L?
        if self.validate(eightLiter, fiveLiter + (5-fiveLiter), threeLiter-(5-fiveLiter)):
            list.append("Fill5Lfrom3L")

        #Fill3Lfrom8L - can we fill 3L from 8L?
        if self.validate(eightLiter-(3-threeLiter), fiveLiter, threeLiter+(3-threeLiter)):
            list.append("Fill3Lfrom8L")

        #Fill3Lfrom5L - can we fill 3L from 5L?
        if self.validate(eightLiter, fiveLiter-(3-threeLiter), threeLiter+(3-threeLiter)):
            list.append("Fill3Lfrom5L")


        #Empty5Lto3L - can we empty 5L to 3L?
        if self.validate(eightLiter, fiveLiter-fiveLiter, threeLiter+fiveLiter):
            list.append("Empty5Lto3L")

        #Empty3Lto5L - can we empty 3L to 5L?
        if self.validate(eightLiter, fiveLiter+threeLiter, threeLiter-threeLiter):
            list.append("Empty3Lto5L")

        #print(eightLiter, fiveLiter, threeLiter)
        #print(list)

        return list

    def validate(self, eightLiter, fiveLiter, threeLiter):
        #verify no number is negative
        if eightLiter < 0 or fiveLiter < 0 or threeLiter < 0:
            return False
        #verify no number is greater than the max
        if eightLiter > 8 or fiveLiter > 5 or threeLiter > 3:
            return False
        #might be more conditions?..nah
        return True  
        
        
    def result(self, state, action):
        #Inefficient because we are redoing what we did in actions, but this keeps actions distinct from states
        #Again, temp variables for clarity:
        eightLiter, fiveLiter, threeLiter = state[JUG.eightCurrent], state[JUG.fiveCurrent], state[JUG.threeCurrent]

        if action=="5from8Lto5L":
            newState = (eightLiter-5, fiveLiter+5, threeLiter) #possibly no longer necessary
        elif action=="3from8Lto3L": 
            newState = (eightLiter-3, fiveLiter, threeLiter+3) #possibly no longer necessary
        elif action=="3from5Lto3L": 
            newState = (eightLiter, fiveLiter-3, threeLiter+3) #possibly no longer necessary
        elif action=="5from5Lto8L": 
            newState = (eightLiter+5, fiveLiter-5, threeLiter) #possibly no longer necessary    
        elif action=="3from3Lto8L": 
            newState = (eightLiter+3, fiveLiter, threeLiter-3) #possibly no longer necessary     
        elif action=="3from3Lto5L":
            newState = (eightLiter, fiveLiter+3, threeLiter-3) #possibly no longer necessary
        elif action=="Fill8Lfrom5L":
            newState = (eightLiter+(8-eightLiter), fiveLiter-(8-eightLiter), threeLiter)
        elif action=="Fill8Lfrom3L": 
            newState = (eightLiter+(8-eightLiter), fiveLiter, threeLiter-(8-eightLiter))
        elif action=="Fill5Lfrom8L": 
            newState = (eightLiter-(5-fiveLiter), fiveLiter+(5-fiveLiter), threeLiter)
        elif action=="Fill5Lfrom3L": 
            newState = (eightLiter, fiveLiter + (5-fiveLiter), threeLiter-(5-fiveLiter))        
        elif action=="Fill3Lfrom8L": 
            newState = (eightLiter-(3-threeLiter), fiveLiter, threeLiter+(3-threeLiter))       
        elif action=="Fill3Lfrom5L":
            newState = (eightLiter, fiveLiter-(3-threeLiter), threeLiter+(3-threeLiter))
        elif action=="Empty5Lto3L": 
            newState = (eightLiter, fiveLiter-fiveLiter, threeLiter+fiveLiter)       
        elif action=="Empty3Lto5L":
            newState = (eightLiter, fiveLiter+threeLiter, threeLiter-threeLiter)

        return newState 


def main():
    #Given  three  jugs:  8,  5  and  3  liters  capacity,  divide  8  liters  in  half  (4  +  4  liters)  with  
    #the  minimum number of water transfers. Note that the 8-liter jug is initially filled with 8 liters of water 
    #and the other two jugs are empty - that is all the water you have.
    print('Jugs Problem: ')
    print(' Tuples are in this format --> [<Node (eightLiter,fiveLiter,threeLiter)>]')
    initState = (8,0,0)
    goalState = (4,4,0)

    problem = JUG(initState, goalState)
    goal = breadth_first_search(problem)
    print("\nPath = ",goal.path(),"\n\nPath cost = ",goal.path_cost)
    print()
    print("\nSolution = ",goal.solution())

main()