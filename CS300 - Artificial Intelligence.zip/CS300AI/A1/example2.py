
from search import Problem, breadth_first_search,depth_first_search, iterative_deepening_search
from search import UndirectedGraph,GraphProblem,Graph
from utils import Dict

#______________________________________________________________________________
#Define the Romania problem by simply creating the graph data structure directly

#edge or g costs based on actual travel distances
romania = UndirectedGraph(Dict(
    A=Dict(Z=75, S=140, T=118),
    B=Dict(U=85, P=101, G=90, F=211),
    C=Dict(D=120, R=146, P=138),
    D=Dict(M=75),
    E=Dict(H=86),
    F=Dict(S=99),
    H=Dict(U=98),
    I=Dict(V=92, N=87),
    L=Dict(T=111, M=70),
    O=Dict(Z=71, S=151),
    P=Dict(R=97),
    R=Dict(S=80),
    U=Dict(V=142)))
 
def romaniaTest():
    problem = GraphProblem('A','B',romania)  
    #goal = depth_first_search(problem)
    goal = iterative_deepening_search(problem)
    print("Path = ",goal.path())
    print("Cost = ",goal.path_cost)

#______________________________________________________________________________

def simpleGraphTest():
    '''
    Graph similar to lily pad problem: 121212222
    121
    212
    222
   
    convert to this:
    <0,0>: <0,1>, <1,0>
    <0,1>: <2,1>
    <0,2>: <0,1>, <1,1>
    
    <1,0>: <1,2>
    <1,1>: <0,1>, <1,0>, <1,2>, <2,1>
    <1,2>: <1,0>
    
    <2,0>: <0,0>, <2,2>
    <2,1>: <0,1>
    <2,2>: <0,2>, <2,0>
    use that to create graph
    '''
    g = Graph(
                {
                    (0,0): {(0,1): 1, (1,0): 1},
                    (0,1): {(2,1): 1},
                    (0,2): {(0,1): 1, (1,1): 1},
                    
                    (1,0): {(1,2): 1},
                    (1,1): {(0,1): 1, (1,0): 1, (1,2): 1, (2,1): 1,},
                    (1,2): {(1,0): 1},  
                    
                    (2,0): {(0,0): 1, (2,2): 1},
                    (2,1): {(0,1): 1},
                    (2,2): {(0,2): 1, (2,0): 1},
                }, directed=True)
    
    problem = GraphProblem((0,0),(2,1),g)  
    goal = breadth_first_search(problem)
    
    if goal is None:
        print("No solution exists")
        return
    
    print("Path = ",goal.path(),"\n\nPath cost = ",goal.path_cost)
    
    solution = goal.solution();
    print("Solution = ",solution)
    
    #convert the states to "actions" because in a graph, the next state is the 
    #"action". In this case, we can simply extract the "actions" from the solution, after it is generated
    actions = []
    prev = (0,0)
    for x in solution:
        if prev[0]-x[0]>0:
            actions.append('U')
        elif prev[0]-x[0]<0:
            actions.append('D')
        elif prev[1]-x[1]<0:
            actions.append('R')
        elif prev[1]-x[1]<0:
            actions.append('L')
        prev = x
           
    print(''.join(actions))
    	   
 #______________________________________________________________________________   
 
def main():
    simpleGraphTest()
    #romaniaTest()
    	
main()