"""
V1.0
"""
from search import Problem, breadth_first_search,depth_first_search, iterative_deepening_search

#______________________________________________________________________________
#An implementation of the Missionary-Cannibal problem
# Tuple format = [<Node (leftMissionaries, rightMissionaries, leftCannibals, rightCannibals, boatSide)>]
class MCP(Problem):
    #state is a tuple(LM,RM,LC,RC,B) with initial value (0,3,0,3,1)
    #last value flips between 1(R) and 0(L)   
    LM=0; RM=1; LC=2; RC=3; B=4 #class "constants"
    
    def __init__(self, initState,goalState):
    	Problem.__init__(self, initState, goalState)
    
    def actions(self, state):     
        # In this kind of simple example, it is common to use the new state itself as the action, 
        # because it is straightforward and more efficient.
        # We don't do that here just to illustrate how we can denote actions separately from states, if so desired.
        
        # list of descriptive actions
        list=[]
        #temp variables for clarity:
        lm, rm, lc, rc, boat = state[MCP.LM], state[MCP.RM], state[MCP.LC],state[MCP.RC], state[MCP.B]
        
        if boat == 1: #boat on the right side
            #1ML - can we move 1 missionary left?
            if self.validate(lm+1, rm-1, lc, rc, 0):
                list.append("1ML")
                
            #2ML - can we move 2 missionaries left?
            if self.validate(lm+2, rm-2, lc, rc, 0):
                list.append("2ML")   
                
            #1CL - can we move one cannibal left?
            if self.validate(lm ,rm, lc+1, rc-1, 0):
                list.append("1CL")
                
            #2CL - can we move two cannibals left?
            if self.validate(lm, rm, lc+2, rc-2, 0):
                list.append("2CL")     
                
            #1M1CL -  can we move one missionary and one cannibal left?
            if self.validate(lm+1, rm-1, lc+1, rc-1, 0):
                list.append("1M1CL")   
                
        else:   #boat on the left side
            #1MR - can we move 1 missionary right?
            if self.validate(lm-1, rm+1, lc, rc, 1):
                list.append("1MR")
                
            #2MR - can we move 2 missionaries right?
            if self.validate(lm-2, rm+2, lc, rc, 1):
                list.append("2MR")    
                
            #1CR - can we move 1 cannibal right?
            if self.validate(lm, rm, lc-1, rc+1, 1):
                list.append("1CR")
                
            #2CR - can we move 2 cannibals right?
            if self.validate(lm, rm, lc-2, rc+2, 1):
                list.append("2CR")    
                
            #1M1CR-  can we move one missionary and one cannibal right?
            if self.validate(lm-1, rm+1, lc-1, rc+1, 1):
                list.append("1M1CR")   
                
        return list

    def validate(self, lm, rm, lc, rc, boat):
        #verify no number is negative
        if lm < 0 or rm < 0 or lc < 0 or rc < 0:
            return False
        #verify no number is greater than the max
        if lm > 3 or rm > 3 or lc > 3 or rc > 3:
            return False
        #verify if boat is on right, then there must be someone on the right side
        if boat == 1 and (rm + rc)==0:
            return False
        #verify if boat is on left, then there must be someone on the left side
        if boat == 0 and (lm + lc)==0:
            return False
        #verify left missionaries are >= left cannibals, unless there are no missionaries on the left
        if lm < lc and lm != 0:
            return False
        #verify right missionaries are >= right cannibals, unless there are no missionaries on the right
        if rm < rc and rm != 0:
            return False
        return True  
        
        
    def result(self, state, action):
        #Inefficient because we are redoing what we did in actions, but thsi keeps actions distinct from states
        #Again, temp variables for clarity:
        lm, rm, lc, rc, boat = state[MCP.LM], state[MCP.RM], state[MCP.LC],state[MCP.RC], state[MCP.B]
        
        if action=="1ML":
            newState = (lm+1, rm-1, lc, rc, 0)
        elif action=="2ML": 
            newState = (lm+2, rm-2, lc, rc, 0)
        elif action=="1CL": 
            newState = (lm ,rm, lc+1, rc-1, 0)
        elif action=="2CL": 
            newState = (lm, rm, lc+2, rc-2, 0)        
        elif action=="1M1CL": 
            newState = (lm+1, rm-1, lc+1, rc-1, 0)       
        elif action=="1MR":
            newState = (lm-1, rm+1, lc, rc, 1)    
        elif action=="2MR":  
            newState = (lm-2, rm+2, lc, rc, 1)
        elif action=="1CR": 
            newState = (lm, rm, lc-1, rc+1, 1)
        elif action=="2CR":
            newState = (lm, rm, lc-2, rc+2, 1)
        elif action=="1M1CR":
            newState = (lm-1, rm+1, lc-1, rc+1, 1)

        return newState 


def main():
    #Runs the Cannibals and Missionary problem, will provide a solution to getting all missionaries
    #and all cannibals to the other side, without missionaries ever being outnumbered by cannibals
    #on either side.
    print('Missionaries/Cannibals Problem: ')
    print(' Tuples are in this format --> [<Node (leftMissionaries, rightMissionaries, leftCannibals, rightCannibals, boatSide)>]')
    initState = (0,3,0,3,1)
    goalState = (3,0,3,0,0)

    problem = MCP(initState, goalState)
    goal = breadth_first_search(problem)
    print("\nPath = ",goal.path(),"\n\nPath cost = ",goal.path_cost)
    print()
    print("\nSolution = ",goal.solution())

main()