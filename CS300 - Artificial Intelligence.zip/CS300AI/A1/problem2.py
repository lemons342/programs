
from search import Problem, breadth_first_search,depth_first_search, iterative_deepening_search
from search import UndirectedGraph,GraphProblem,Graph
from utils import Dict
import time

def lilyPadProblem(pond):
    
    print('Pond:', pond)

    g = Graph(
                {
                    (0,0): {},
                    (0,1): {},
                    (0,2): {},
                    (0,3): {},
                    (0,4): {},
                    
                    (1,0): {},
                    (1,1): {},
                    (1,2): {},  
                    (1,3): {},
                    (1,4): {},
                    
                    (2,0): {},
                    (2,1): {},
                    (2,2): {},
                    (2,3): {},
                    (2,4): {},

                    (3,0): {},
                    (3,1): {},
                    (3,2): {},  
                    (3,3): {},
                    (3,4): {},

                    (4,0): {},
                    (4,1): {},
                    (4,2): {},  
                    (4,3): {},
                    (4,4): {},
                }, directed=True)

    twod_graph = [[0 for i in range(5)] for j in range(5)] #2D graph declaration

    goalState = None

    for i in range(5):
        for j in range(5):
            twod_graph[i][j] = pond[j+(5*i)] #turning pond string into 2D graph
            if (twod_graph[i][j] != 'G'):
                neighbor = int(twod_graph[i][j]) #jump-to-neighbor pad value
                if ((i - neighbor) >= 0):               
                    g.connect((i,j),((i-neighbor),j)) #connect current pad with north jump neighbor
                if ((j + neighbor) < 5):
                    g.connect((i,j), (i,(j+neighbor))) #connect current pad with east jump neighbor
                if ((i + neighbor) < 5):
                    g.connect((i,j), ((i+neighbor),j)) #connect current pad with south jump neighbor
                if ((j - neighbor) >= 0):
                    g.connect((i,j),(i,(j-neighbor))) #connect current pad with west jump neighbor
            else:
                goalState = (i,j)   #if twod_graph[i][j] == 'G', make goal state

    #print(twod_graph) #print 2D graph
   
    #print(twod_graph[-4][-3]) testing negative array values to find G, avoid negative values in future

    print('Goal:',goalState) #print goalState

    problem = GraphProblem((0,0),goalState,g)  
    goal = breadth_first_search(problem)
    
    if goal is None:
        print("No solution exists")
        return
    
    print("Path = ",goal.path(),"\n\nPath cost = ",goal.path_cost)
    
    solution = goal.solution();
    print("Solution = ",solution)
    
    #convert the states to "actions" because in a graph, the next state is the 
    #"action". In this case, we can simply extract the "actions" from the solution, after it is generated
    actions = []
    prev = (0,0)
    for x in solution:
        if prev[0]-x[0]>0:
            actions.append('U')
        elif prev[0]-x[0]<0:
            actions.append('D')
        elif prev[1]-x[1]>0:
            actions.append('L')
        elif prev[1]-x[1]<0:
            actions.append('R')
        prev = x
           
    print(''.join(actions))
    	   
 #______________________________________________________________________________   
 
def main():
    pond = '332344212G421324113131122'

    start = time.time()

    lilyPadProblem(pond)

    end = time.time()
    print('Time:',end - start,'seconds')
    	
main()