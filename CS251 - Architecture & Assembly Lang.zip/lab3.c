/***********************************************************************
 * Lab 3
 * Author:      write your full name here
 * Description: write your precise yet concise program description here
 * Known bugs:  write your precise yet concise bug description(s) here
 ***********************************************************************/
#include <stdio.h>

#define NUM_BITS 16

int main(void) {
  short unsigned int n1, n2;       // user inputs
  int b1[NUM_BITS], b2[NUM_BITS];  // binary representation of inputs
  short unsigned sum;              // sum of n1 and n2
  int b[NUM_BITS];                 // binary representation of sum
  int carry = 0;                   // carry-in to each column in the addition 
  int power = 1;                   // some power of two
  
  printf("Enter an integer between 0 and 65535: n1 = ");
  scanf(" %hu", &n1);

  printf("Enter an integer between 0 and 65535: n2 = ");
  scanf(" %hu", &n2);  
  
  /* Write your code below this comment block. Do NOT modify anything above.

     For full credit, your code below MUST meet ALL of the requirements listed
     in the lab handout.
   */

  // a single FOR loop that performs ALL binary and decimal computations
  sum = n1 + n2;
  for(int i = 0; i < NUM_BITS; i++) {
    b1[i] = ((n1 >> i) & power);
    b2[i] = ((n2 >> i) & power);
    b[i] =  ((sum >> i) & power);
  }//  computation loop


  // several FOR loops that ONLY perform formatted output (but NO computations)
  printf("   ");
  for (int i = NUM_BITS-1; i >= 0; i--) {
    printf("%d", b1[i]);
  }
  printf("\n + ");
  for (int i = NUM_BITS-1; i >= 0; i--) {
    printf("%d", b2[i]);
  }
  printf("\n   ");
  for (int i = NUM_BITS-1; i >= 0; i--) {
    printf("-");
  }
  printf("\n = ");
  for (int i = NUM_BITS-1; i >= 0; i--) {
    printf("%d", b[i]);
  }
  printf(" = %d\n", sum);

  // to be completed
  
  /* your code goes above this line; do NOT modify the code below */
  
  return 0;
}// main 
