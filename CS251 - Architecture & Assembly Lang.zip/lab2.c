/***********************************************************************
 * Lab 2
 * Author:      Nick Lemerond
 * Description: counts the total number of bit-clearing operations that
   are needed to count from the 16-bit integer min to the 16-bit integer max
 * Known bugs:  
 ***********************************************************************/

#include <stdio.h>             // needed for scanf and printf

#define NUM_BITS 16            // size of integer-representation scheme

int main(void) {
  short unsigned int min, max; // the two numbers to be entered by the user
  unsigned int count;          // the number of bit-clearing operations
  unsigned short int bit, n;   // loop indices
  unsigned short int num;      // current number in the counting process
  unsigned short int numPlus1; // next number in the counting process
  
  printf("Enter an integer between 0 and 65535:        min = ");
  scanf(" %hu", &min);

  printf("Enter an integer between 0 and 65535: min <= max = ");
  scanf(" %hu", &max);  

  /* Write your code below. Do NOT modify anything between the top comment 
     block and this comment block. 

     For full credit, your code below MUST meet ALL of the requirements listed
     in the lab handout.
   */

  count = 0;

  //run loop up to 16 because of number of bits
  for (int i = 0; i < 16; i++) {
     //loop through numbers between min number and max number
     for (int j = 0; j < max-min; j++) {
       //if min bit is greater than min+1 bit then count ++
       if(((min+j >> i) & 1) > (((min+j+1) >> i) & 1)) {
        count++;
        }
     }
  }




  /* For full credit, do NOT modify the code below this point */
  
  printf("total number of bit-clearing operations: %d\n", count);
  
  return 0;
}// main
