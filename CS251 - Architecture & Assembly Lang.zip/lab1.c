/***********************************************************************
 * Lab 1
 * Author:      Nick Lemerond
 * Description: Count the number of identical bits in the 8-bit representation
                of two positive integers
 * Known bugs:  None
 ***********************************************************************/

#include <stdio.h>           // needed for scanf and printf

int main(void) {
  short unsigned int n1, n2; // the two numbers to be compared
  short unsigned int count;  // the number of bits that n1 and n2 share
  
  printf("Enter an integer between 0 and 255: n1 = ");
  scanf(" %hu", &n1);

  printf("Enter an integer between 0 and 255: n2 = ");
  scanf(" %hu", &n2);  
  
  /* Write your code below. Do NOT modify anything between the top comment 
     block and this comment block. 

     For full credit, your code below MUST meet ALL of the requirements listed
     in the lab handout.
   */
  count = 0;
  //run loop up to 8 bits because highest number is 255
  for (int i = 0; i < 8; i++) {
    //right shift both by i and check if bit at 0th position is the same
    if (((n1 >> i) & 1) == ((n2 >> i) & 1)) {
      count++;
    }
  }


  
  /* For full credit, do NOT modify the code below this point */
  
  printf("n1 and n2 have %d bit(s) in common\n", count);
  
  return 0;
}// main
