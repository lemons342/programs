/*********************************************************************
 * Lab 6
 * Author:       Nick Lemerond
 * Description:  prompts the user for a positive integer n and computes the value
                 of collatz(n) equal to the number of steps it takes for n to become equal to 1
 * Known bugs:   Won't compile
 *********************************************************************/

#include "stdio.h"   // needed for printf and scanf
#include "stdlib.h"  // needed for dynamic memory allocation

#define GROW_BY 2    // multiplicative factor of growth of array length

/* send to the console the contents of the array whose first and last elements
   are referenced by the two arguments, respectively.
   All array elements must appear on one line. Each printed element must be
   followed by one space. The printed line must end with one newline character.
   
   Implementation requirements:
   + Do NOT declare any variables.
   + The body of this function must contain exactly one WHILE loop followed by 
     one printf statement.
   + The body of the loop must contain exactly one statement.
 */
void printTrace(int *first, int *last) {
    while (*last > *first) {
    printf("");
    }
    printf("\n");
  
}// printTrace

/* return the number of times the input sequence (whose first and last elements
   are referenced by the two arguments, respectively) goes up.
   
   Implementation requirements:
   + Do NOT modify the given code.
   + Do NOT declare any new variables.
   + You may only add one WHILE loop whose body contains exactly one assignment
     statement (and nothing else)
   + You may NOT use any conditional constructs (e.g., IF/SWITCH statements) or 
     a ternary conditional expression, nor the % (modulo or remainder) operator.
 */
int countUpMoves(int *first, int *last) {
  int count = 0;

  /* write your WHILE loop below */

  while (*first < *last) {
      count++;
  }
  
  return count;
}// countUpmoves

/* Complete the main function below
 */
int main(void) {
  int step;           // counter for the number of steps in the computation 
  int size;           // actual size of the array a below

  /* do NOT declare any new variables (except a below) */
  
  /* declare and dynamically allocate space for a one-int array called a */

  int a = (int*) malloc((5 * sizeof(int)));
  if (a == NULL) { // something went WRONG
    printf("Error. Wrong input size.");
    //return 0;
  }

  
  /* prompt the user for n, input n, and initialize all variables as needed */

  printf("Enter a positive integer: n = ");
  scanf("%d", &a[0]);
  
  /* compute collatz(n), storing the results of all steps in a */
  
  step = 1;
  while (a[0] > 1)
	{
	  if (a[0] % 2 == 0) {
	  	a[step] = a[0] / 2;
	  } else {
	   	a[step] = 3 * a[0] + 1;
	  }
	
	step++;
	}
    size = sizeof(a);
  /* print collatz(n), the size of a, and the number of up moves in the trace */

  printf("collatz(n) = %d [size of a = %d / %d up moves", size, size + 1, countUpMoves(a[1], a[size]))
  
  /* print the full trace */

  printTrace(a[1], a[size]);
  
  /* clean up */

  free(a); 
  
  return 0;
}// main
