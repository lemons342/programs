<?php

// TO BE COMPLETED
// Define your database credentials as constants 
// (see 6.2 in the zyBook for refresher on constants)
define("DB_SERVER", "localhost"); // Always connect to localhost (do not change this constant)
define("DB_NAME", "lemern75"); // Because the name of your database is your username
define("DB_USER", "lemern75" );
define("DB_PWD", "mysql849975");

?>
