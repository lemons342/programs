<?php
require('database.php');
$db = db_connect();

/*
TODO:
Implement endpoints described in the lab writeup

Hints:
- Use $_SERVER["REQUEST_METHOD"] to detect if a request is a GET or POST request
- If it's a GET request, you can use empty($_GET) to check if there are no GET parameters
- Look at database.php to see what's implemented for you...
*/
if(isset($_SERVER["REQUEST_METHOD"])){
  // GET Endpoints
    
  if(isset($_GET['lastId'])){
  // case where get last id found
    $lastId = $_GET['lastId'];
    //get last id

    if($lastId == -1){
      // Endpoint for getting the complete chat history
      // GET /chat.php
      $output[] = get_chats();

    } else{
      // Endpoint for getting new chats since given last chat id
      // GET /chat.php?last_id=#
      $output[] = get_chats($lastId);
    }

    echo json_encode($output);
  }
    

  // Endpoint for user sending new chat
  // POST /chat.php
  if($_SERVER["REQUEST_METHOD"] == "POST"){
    $_POST = json_decode(file_get_contents('php://input'), true);
    $user = $_POST[0];
    $message = $_POST[1];

    $input = insert_chat($user, $message);
    
    if(isset($input["status"])){
      if($input["status"] == "ok")
        echo("WORKED!");
      if($input["status"] == "error")
        echo($input["error"]);
    }
    // Hint: If using JSON data for POST, 
    // need to populate $_POST superglobal yourself with:
    // $_POST = json_decode(file_get_contents('php://input'), true);
    // Hint: Use JSON data, form data is restrictive

  }
  // Set content type to json, and output json in page to be sent
}


db_disconnect();

?>