const CHAT_API = "http://webdev.cs.uwosh.edu/students/lemern75/labs/chat.php";
const API_KEY = "1OvQ9MSftpRMAkurbc9dKq8K9VCECoCG";
// Get page elements needed for JS code
const gifsDiv = document.getElementById("gifs");
const chatWindow = document.getElementById("chat-window");
const textInput = document.getElementById("input");
const chatForm = document.getElementById("chat-form");

// When a user presses enter while typing in the text area,
// send the text that was typed
textInput.addEventListener("keydown", function(event) {
  if(event.key === "Enter") {
    sendTextMessage();
  }
});

// When a user presses the send button, 
// send the text that was typed
chatForm.addEventListener("submit", function(event) {
  event.preventDefault();
  sendTextMessage();
});

// Global variable to keep track of the last id of the user's chat window
let lastId = -1;

// When a user first loads the page, prompt them for their user name
const curUser = prompt("Who would you like to chat as today?");

// Have the user "join the chat"
joinChat();

// Set an interval to check for new chats every second
let checkingNew = setInterval(checkForNew, 1000);

/**
 * TODO:
 * Call getChats with the endpoint to get all chats
 */
function joinChat() {
  getChats(lastId);
}

/**
 * TODO: 
 * Call getChats with the endpoint to get chats since the last 
 * chat the user has in their chat window
 */
function checkForNew() {
  getChats(lastId);
  // Hint: Use the lastId global variable
}

/**
 * TODO:
 * Contact your chat.php API to get chats using the given endpoint
 * Update the lastId global variable based on the results
 * Load any new chats in the chat window by calling loadNewChats()
 * @param {String} endpoint endpoint to hit for getting chats
 */
function getChats(endpoint) {
  let ajax = new XMLHttpRequest();
  endpoint = `lastId=${lastId}`;
  ajax.open("GET", `${CHAT_API}?${endpoint}`);
  ajax.responseType = "json";
  ajax.send();

  ajax.onreadystatechange = function() {
    if (ajax.readyState == 4 && ajax.status == 200){// Find is submit is done
      let response = this.response;

      if((response[0].status == "ok")){// Check if it is ok
        if(response[0].chats.length != 0){
          let chats = response[0].chats;// Get chat array
          let idsFound = chats.length;

          if(chats[idsFound-1].id > lastId){// Check id to see if a new chat
            lastId = chats[idsFound-1].id;// Assign new last id
            loadNewChats(chats);// Load chats within the passed array
          }
        }
      }else {
        alert("An error has occured please reload the page and try again.");
      }
    }
  
    // Hint: Make use of loadNewChats() method, implemented for you below
  }
  
}

/**
 * Adds the given chats to the chat window
 * 
 * @param {Array} chats chat array where each element 
 * is a chat object with id, user and message keys
 */
function loadNewChats(chats) {
  for(let chat of chats) {
    // Create user span
    let userPart = document.createElement("span");
    userPart.innerHTML = `${chat.user}:`;// Had to modify
    userPart.className = "user";//^couldn't see var

    // Create message span
    let msgPart = document.createElement("span");
    msgPart.innerHTML = chat.message;// Had to modify
    msgPart.className = "message";//^couldn't see var

    // Add the spans to the chat window
    chatWindow.appendChild(userPart);
    chatWindow.appendChild(msgPart);

    // Automatically scroll down for the user
    chatWindow.scrollTop = chatWindow.scrollHeight;
  }
}

/**
 * When sending a gif, send the HTML code to render it
 * (so "<img src=...") given by the img elements outerHTML
 * This function should be bound to gif img clicks
 */
function sendGif() {
  sendMessage(this.outerHTML);
}

/**
 * When sending text, send what's in the text box
 */
function sendTextMessage() {
  sendMessage(textInput.value);
}

/**
 * TODO:
 * POST the given message to the chat API 
 * Hint: Use JSON data, form data may be too restrictive...
 * If successful, clear out the text input: textInput.value = "";
 * @param {String} msg Message to send to the chat API
 */
function sendMessage(msg) {
  let ajax = new XMLHttpRequest();
  ajax.open("POST", "chat.php");
  ajax.setRequestHeader("Content-type", "application/json");
  ajax.responseType = "json";
  let input = [curUser, msg];
  jsonInput =JSON.stringify(input)
  ajax.send(jsonInput);
  document.getElementById("input").value = "";
}


/**
 * TODO:
 * When a user asks for gifs by clicking Get Gifs button, 
 * search for gifs using GIPHY API with the text in the 
 * textInput textbox as the search query for gifs
 * 
 * When gifs are returned,
 * clear out the current gifs,
 * create img elements for each gif result (details in lab writeup)
 * add a listener to each img to be able to send it in the chat
 * and add the img to the gif div
 */
document.getElementById("gif-btn").addEventListener("click", function() {
  let searchQuery = textInput.value;
  gifsDiv.innerHTML = "";// Clear gif dif
  const url = `https:api.giphy.com/v1/gifs/search?api_key=${API_KEY}&q=${searchQuery}`;
  fetch(url)
    .then(response => response.json())
    .then(data =>{
        if(data.meta.msg === 'OK'){// Check if response is good
          for(let gif of data.data){
            let gifImg = document.createElement("img");
            gifImg.src = gif.images.fixed_height_small.url;
            gifImg.alt = gif.images.title;
            gifImg.addEventListener("click",sendGif);
            gifsDiv.appendChild(gifImg);
          }
        }
    })
    .catch(err =>{
      console.error(err);
    })
});