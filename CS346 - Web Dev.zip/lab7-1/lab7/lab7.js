const minInput = document.getElementById("min");
const maxInput = document.getElementById("max");
const opInput = document.getElementById("op-choice");
const secondsInput = document.getElementById("numSeconds");
const errorPrint = document.getElementById("error");
const formInput = document.getElementById("input-div");
const flashcard = document.getElementById("flashcard");
const scorePanel = document.getElementById("score-panel");
var score = document.getElementById("score");
var guess = document.getElementById("answer");
var subAnswer = document.getElementById("submit-answer");


function formSubmit(event) {
    console.log(event);
    console.log(this);

    let min = parseInt(minInput.value);
    let max = parseInt(maxInput.value);


    if (min > max) {
        errorPrint.innerHTML = "Min must be smaller than max";
    } else if (isNaN(min)) {
        errorPrint.innerHTML = "Please enter min value";
    } else if (isNaN(max)) {
        errorPrint.innerHTML = "Please enter max value";
    } else {
        //errorPrint.innerHTML = min + " " + max; //debugging
        flashcard.classList.remove('hidden');
        scorePanel.classList.remove('hidden');
        timer.classList.remove('hidden');
        document.getElementById("answer").focus();
        guess.style.backgroundColor = "white";
        guess.readOnly = false;
        subAnswer.style.backgroundColor = "white";
        subAnswer.disabled = false;

        var countDown = secondsInput.value;
        var seconds = document.getElementById('seconds');
        seconds.innerText = countDown;
        var cancel = setInterval(incrementSeconds, 1000);


        score.innerHTML = 0;
        let answer = 0;

        function runOperations() {
            const value1 = Math.floor((Math.random() * (max - min + 1)) + min);
            document.getElementById("op1").innerHTML = value1;
            const value2 = Math.floor((Math.random() * (max - min + 1)) + min);
            document.getElementById("op2").innerHTML = value2;

            let operation = opInput.value

            if (opInput.value != "random") {
                document.getElementById("op").innerHTML = operation;
            } else {
                const operations = ["+", "-", "*"];
                operation = operations[Math.floor(Math.random() * operations.length)];
                document.getElementById("op").innerHTML = operation;
            }

            answer = eval(value1 + operation + value2);
        }

        runOperations(); //get operations


        function answerSubmit(event) {
            console.log(event);
            console.log(this);

            let answerCorrect = false;

            if (guess.value == answer) {
                score.innerHTML = parseInt(score.innerHTML) + 1;
                answerCorrect = true;
            } else {
                //timer.innerHTML = "Answer = " + answer; //debugging
                guess.style.backgroundColor = "lightcoral";
            }

            if (answerCorrect) {
                runOperations(); //run operations again each submit
                guess.style.backgroundColor = "white";
                guess.value = "";
            }

            event.preventDefault();
        }

        function incrementSeconds() {
            if (countDown != 0) countDown -= 1;
           seconds.innerText = countDown;
            if (countDown == 0) {
                guess.style.backgroundColor = "lightblue";
                guess.readOnly = true;
                subAnswer.style.backgroundColor = "lightblue";
                subAnswer.disabled = true;
                clearInterval(cancel);
            }
        }

        flashcard.addEventListener('submit', answerSubmit);
    }
    event.preventDefault();
}
formInput.addEventListener('submit', formSubmit);


