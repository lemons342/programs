<?php
if($_SERVER["REQUEST_METHOD"] === "GET") {
  echo "THIS IS A GET REQUEST";
} else {
  echo "THIS IS A POST REQUEST";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab 6</title>

    <link rel="stylesheet" href="lab6.css">
</head>
<body>
    <!-- If accessing form page from server, use relative path: -->
    <!-- <form action="form_processing.php" method="POST" -->
    <!-- Absolute path to test locally: -->
    <form action="form_processing.php" method="POST">

        <fieldset class="horizontal-controls">
            <legend>User info</legend>
            <ul>
                <li>
                    <label for="myname">Name:</label>
                    <input type="text" id="myname" name="thename">
                </li>
                <li>
                    <input type="radio" id="semester1" name="mysemester" value="Semester 1" checked>
                    <label for="semester1">Semester 1</label>
                </li>
                
                <li>
                    <input type="radio" id="semester2" name="mysemester" value="Semester 2">
                    <label for="semester2">Semester 2</label>
                </li>
            </ul>
        </fieldset>

        <legend>Mad Lib Inputs</legend>
        <ul>
            <li>
                <label for="noun">Plural Noun:</label>
                <input type="text" id="noun" name="noun1" required>
            </li>
            <li>
                <label for="noun">A Strange Noun:</label>
                <input type="text" id="noun" name="noun2" required>
            </li>
            <li>
                <label for="location">A Location:</label>
                <input type="text" id="location" name="location1" required>
            </li>
            <li>
                <label for="animal">Plural Aquatic Animals:</label>
                <input type="text" id="animal" name="animal1" required>
            </li>
            <li>
                <label for="mycheckbox1">Cute:</label>
                <span class="form-control-fill"><input type="checkbox" id="mycheckbox1" name="checkbox[]" value="cute"></span>
            </li>

            <li>
                <label for="mycheckbox2">Disgusting:</label>
                <span class="form-control-fill"><input type="checkbox" id="mycheckbox2" name="checkbox[]" value="disgusting"></span>
            </li>

            <li>
                <label for="mycheckbox3">Cuddly:</label>
                <span class="form-control-fill"><input type="checkbox" id="mycheckbox3" name="checkbox[]" value="cuddly"></span>
            </li>
            <li>
                <label for="choose">Choose:</label>
                <select name="choose1" id="choose" size="3" >
                    <option value="tasty" selected>Tasty</option>
                    <option value="yummy">Yummy</option>
                    <option value="juicy">Juicy</option>
                </select>
            </li>
            <li>
                <label for="slippery">Something Slippery:</label>
                <input type="text" id="slippery" name="slippery1" required>
            </li>
            <li>
                <label for="bodypart">Body Part:</label>
                <input type="text" id="bodypart" name="bodypart1" required>
            </li>
        </ul>

        <div id="form-buttons">
            <input type="reset" value="Clear the form" id="reset-btn">
            <input type="submit" value="Send form data to server" id="submit-btn" >
        </div>
    </form>

    <footer>
        <p>
            <a href="http://validator.w3.org/check/referer" 
               referrerpolicy="unsafe-url">
                    Validate My HTML
            </a>
        </p>
        <p>
            <a href="http://jigsaw.w3.org/css-validator/validator?uri=http://webdev.cs.uwosh.edu/students/hillbergh/examples/more_forms.html" 
               referrerpolicy="unsafe-url">
                    Validate My CSS
            </a>
        </p> 
    </footer>
</body>
</html>
