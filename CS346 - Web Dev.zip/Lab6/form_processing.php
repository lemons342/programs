<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab 6</title>

    <link rel="stylesheet" href="lab6.css">
</head>
<body>
    <?php if ($_SERVER['REQUEST_METHOD'] === 'GET') { ?>
        <h1>GET request received with query parameters:</h1>
        <pre>
            <?php print_r($_GET); ?>
        </pre>
        <?php foreach($_GET as $name => $value) {
            if (is_array($value)) { ?>
                <p>
                    <?php echo "{$name}: [" . implode(", ",$value) . "]"; ?>
                </p>
            <?php } else { ?>
                <p>
                    <?php echo "{$name}: " . htmlspecialchars($value); ?>
                </p>
            <?php } 
        }
    }
    // else...
    ?> <Form> <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') { ?>
        <h1>First Day of Web Dev</h1>
        <pre>
            <?php //print_r($_POST); //testing ?>
        </pre>
        <!--
        <?php
        // ksort($_POST);
        foreach($_POST as $name => $value) {
            if (is_array($value)) { ?>
                <p>
                    <?php echo "{$name}: [" . implode(", ", $value) ."]"; ?>
                </p>
            <?php } else { ?>
                <p>
                    <?php echo "{$name}: " . htmlspecialchars($value); ?>
                </p>
            <?php }
        } ?>
        --> 
        <?php
            $input = $_POST["thename"];
            echo "<p>$input</p>";
            $input = $_POST["mysemester"];
            echo "<p>$input</p>";

            echo "<p>";
            $input = $_POST["noun1"];
            echo "  On my first day of Web Dev I was so unprepared. I had <u><b>$input</b></u> in my pockets and a ";
            $input = $_POST["noun2"];
            echo "<u><b>$input</b></u> in my backpack instead of all my folders and notebooks! ";
            $input = $_POST["location1"];
            echo "When we went around the room and said how our summer was I talked about how I went to <u><b>$input</b></u> and swam with the ";
            $input = $_POST["animal1"];
            echo "<u><b>$input</b></u>. They were ";
            if (isset($_POST["checkbox"]))
                foreach ($_POST["checkbox"] as $input) {
                    echo "<u><b>$input</b></u> and ";
                }    
            $input = $_POST["choose1"];
            echo "definitely not <u><b>$input</b></u> when they are cooked. ";
            $input = $_POST["slippery1"];
            echo "At the end of class, I was no longer stressed about not bringing my books but then I slipped on a <u><b>$input</b></u> and broke my ";
            $input = $_POST["bodypart1"];
            echo "<u><b>$input</b></u>! That was so embarassing.";

            echo "</p>";
        ?>
        <a href="https://webdev.cs.uwosh.edu/students/lemern75/labs/lab6.php" 
               referrerpolicy="unsafe-url">
                    Try Again!
        </a>
        <?php
    } ?>
    </form>

    <p>
        <a href="http://validator.w3.org/check/referer" 
            referrerpolicy="unsafe-url">
                Validate My HTML
        </a>
    </p>
    <p>
        <?php $uri = $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>
        <a href="http://jigsaw.w3.org/css-validator/validator?uri=<?= $uri ?>" referrerpolicy="unsafe-url">
                Validate My CSS
        </a>
    </p>

</body>
</html>
