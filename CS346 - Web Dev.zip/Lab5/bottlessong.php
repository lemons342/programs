<?php 
function list_item($text) { ?>
  <li><?= $text ?></li>
<?php } ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <ul>
  <?php for($i = 99; $i >= 0; $i--) { ?>
    <li><?= $i ?> bottles of beer on the wall</li>
  <?php } ?>
  </ul>

  <ul>
  <?php for($i = 99; $i >= 0; $i--) { 
    list_item($i . " bottles of beer on the wall");
  } ?>
  </ul>

</body>
</html>