<?php 

function dec_to_hex($decimal) {
    $hex="";   
    $hexchars=['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'];  
    while($decimal>0)  
     {    
       $hex=$hexchars[bcmod($decimal,'16')].$hex;   
       $decimal=bcdiv($decimal,'16',0);  
     }  
    return $hex;
} 

function next_hex($hex) {   
    $hexchars=['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'];
    $decimal = 0;
    $hex = strval($hex);
    $hexArr = str_split($hex);
    
    $i = 0;
        for ($j=0; $j <= sizeof($hexchars)-1; $j++) {
            if ($hexArr[$i] == $hexchars[$j]) {
                $decimal += ($j * pow(16,(sizeof($hexArr)-$i-1)));
                $i++;
                if ($i > sizeof($hexArr)-1) break;
            }
        }
    $decimal +=1;
    return dec_to_hex($decimal);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="http://webdev.cs.uwosh.edu/students/hillbergh/lab_files/specialcharsstyle.css">
</head>
<body>
<?php
function special_chars_table($num, $decimal) {
    $hex = dec_to_hex($decimal);

       
    for ($i = 0; $i < $num; $i++) {
        $convert = '0x' . $hex;
        printf($hex);
        printf(" ");
        printf(chr($convert));
        echo "</br>";
        $hex = next_hex($hex);
    }
    
}
?>
  <ul>
      <?php 
        dec_to_hex(128512);
      ?>
  </ul>
  <ul>
      <?php 
        $hex = 19;
        next_hex($hex);
      ?>
  </ul>
  <td>
      <?php 
        special_chars_table(5, 65);
        
        special_chars_table(9, 79);
        
        special_chars_table(13, 101);
      ?>
  </td>
  <footer>
    <p>
      <a href="http://validator.w3.org/check/referer" referrerpolicy="unsafe-url">Validate Me</a>
    </p>
  </footer>
</body>
</html>